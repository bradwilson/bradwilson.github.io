﻿using System.Web.Mvc;
using System.Web.Util;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class AntiXssController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        internal static void Initialize()
        {
            HttpEncoder.Current = new AntiXssEncoder();
        }
    }
}
