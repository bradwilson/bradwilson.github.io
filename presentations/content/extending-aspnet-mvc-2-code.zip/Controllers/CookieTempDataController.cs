﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class CookieTempDataController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string message)
        {
            TempData["Message"] = message;
            return RedirectToAction("Index");
        }

        protected override void Initialize(RequestContext requestContext)
        {
            ViewData["cookies"] = EnumerateCookies(requestContext);
            ViewData["session"] = EnumerateSession(requestContext);

            TempDataProvider = new CookieTempDataProvider(requestContext.HttpContext);
            base.Initialize(requestContext);
        }

        #region Here thar be dragons

        public static Dictionary<string, object> EnumerateCookies(RequestContext requestContext)
        {
            return EnumerateCollection(
                requestContext.HttpContext.Request.Cookies.Keys,
                key => requestContext.HttpContext.Request.Cookies[key].Value
            );
        }

        public static Dictionary<string, object> EnumerateSession(RequestContext requestContext)
        {
            return EnumerateCollection(
                requestContext.HttpContext.Session.Keys,
                key => requestContext.HttpContext.Session[key]
            );
        }

        static Dictionary<string, object> EnumerateCollection(IEnumerable keys, Func<string, object> evaluator)
        {
            var result = new Dictionary<string, object>();
            foreach (string key in keys.Cast<string>().Distinct())
            {
                object value = ToDisplayString(evaluator(key));
                if (value != null)
                    result.Add(key, value);
            }
            return result;
        }

        static object ToDisplayString(object value)
        {
            string stringValue = value as string;
            if (stringValue == "")
                return null;

            if (stringValue != null)
                try
                {
                    value = CookieTempDataProvider.Base64StringToDictionary(stringValue);
                }
                catch (Exception) { }

            IDictionary<string, object> dictionary = value as IDictionary<string, object>;
            if (dictionary == null)
                return value;

            return "{ " + dictionary.Select(kvp => kvp.Key + ": " + kvp.Value).Aggregate((left, right) => left + ", " + right) + " }";
        }

        #endregion
    }
}
