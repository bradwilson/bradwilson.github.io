﻿using System.Linq;
using System.Web.Mvc;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class DefaultController : Controller
    {
        public ActionResult Index()
        {
            return View(TypeUtility.Controllers);
        }
    }
}
