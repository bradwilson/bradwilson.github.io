﻿using System.Web.Mvc;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class MyMetadataModel
    {
        public string EmailAddress { get; set; }
    }

    public class FluentMetadataController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(MyMetadataModel model)
        {
            return View(model);
        }

        internal static void Initialize()
        {
            FluentMetadataProvider fluentMetadata = new FluentMetadataProvider();

            fluentMetadata
                .ForProperty<MyMetadataModel>(m => m.EmailAddress)
                .DisplayName("E-mail address");

            ModelMetadataProviders.Current = fluentMetadata;
        }
    }
}