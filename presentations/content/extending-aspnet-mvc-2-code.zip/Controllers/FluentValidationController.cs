﻿using System.Web.Mvc;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class MyValidatedModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string EmailAddress { get; set; }
    }

    public class FluentValidationController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(MyValidatedModel model)
        {
            return View(model);
        }

        internal static void Initialize()
        {
            FluentValidationProvider fluentValidation = new FluentValidationProvider();

            fluentValidation
                .ForProperty<MyValidatedModel>(m => m.Name)
                .Required("Name is required")
                .StringLength(3, 50, "Name must be between 3 and 50 characters");

            fluentValidation
                .ForProperty<MyValidatedModel>(m => m.Age)
                .Range(1, 140, "Age must be between 1 and 140");

            fluentValidation
                .ForProperty<MyValidatedModel>(m => m.EmailAddress)
                .Required("EmailAddress is required")
                .Regex(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}", "EmailAddress must be a valid e-mail address");

            ModelValidatorProviders.Providers.Add(fluentValidation);
        }
    }
}