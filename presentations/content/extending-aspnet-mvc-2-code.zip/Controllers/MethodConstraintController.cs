﻿using System.Web.Mvc;
using System.Web.Routing;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class MethodConstraintController : Controller
    {
        public ActionResult Get()
        {
            return View();
        }

        public ActionResult Post()
        {
            return View();
        }

        internal static void Initialize(RouteCollection routes)
        {
            routes.MapRoute(
                "Index_Get",
                "MethodConstraint",
                new { controller = "MethodConstraint", action = "Get" },
                new { AllowedMethods = new MvcMethodConstraint("GET") }
            );

            routes.MapRoute(
                "Index_Post",
                "MethodConstraint",
                new { controller = "MethodConstraint", action = "Post" },
                new { AllowedMethods = new MvcMethodConstraint("POST") }
            );
        }
    }
}