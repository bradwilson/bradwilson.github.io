﻿using System.Drawing;
using System.Web.Mvc;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class PointController : Controller
    {
        public ActionResult Index()
        {
            return View(new Point(0, 0));
        }

        [HttpPost]
        public ActionResult Index(Point point)
        {
            return View(point);
        }

        internal static void Initialize()
        {
            ModelBinders.Binders.Add(typeof(Point), new PointModelBinder());
        }
    }
}
