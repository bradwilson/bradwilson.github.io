﻿using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class PriceValidatorController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(ProductViewModel model)
        {
            return View(model);
        }
    }

    public class ProductViewModel
    {
        [Required]
        public string Title { get; set; }

        [Required]
        [Price(MinPrice = 3.99,
               ErrorMessage = "Price must end in .99 and be larger than 3.99")]
        public double Price { get; set; }
    }
}
