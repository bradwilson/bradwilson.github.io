﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TechEd2010.Models.Northwind;

namespace TechEd2010.Controllers
{
    public class ScaffoldController : Controller
    {
        NorthwindEntities entities = new NorthwindEntities();

        //
        // GET: /Scaffold/

        public ActionResult Index()
        {
            return View(entities.Products);
        }

        public ActionResult Details(int id)
        {
            return View(entities.Products.Where(p => p.ProductID == id).Single());
        }

    }
}
