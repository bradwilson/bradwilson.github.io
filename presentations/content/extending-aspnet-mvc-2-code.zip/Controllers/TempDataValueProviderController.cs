﻿using System;
using System.Web;
using System.Web.Mvc;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class TempDataValueProviderController : Controller
    {
        public ActionResult Index()
        {
            TempData["Message"] = DateTime.Now;
            return RedirectToAction("Index2");
        }

        public ActionResult Index2(string message)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            return View((object)message);
        }

        internal static void Initialize()
        {
            ValueProviderFactories.Factories.Add(new TempDataValueProviderFactory());
        }
    }
}
