﻿using System.Web.Mvc;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class TimingController : Controller
    {
        [ActionTiming]
        public string Index()
        {
            return "This is simple text";
        }
    }
}
