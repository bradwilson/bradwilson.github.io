﻿using System;
using System.Web.Mvc;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public interface IMyService { }

    public class MyService : IMyService { }

    public class UnityController : Controller
    {
        IMyService myService;

        public UnityController(IMyService myService)
        {
            this.myService = myService;
        }

        public string Index()
        {
            return String.Format("The type of IMyService is {0}", myService.GetType().FullName);
        }

        internal static void Initialize()
        {
            UnityControllerFactory factory = new UnityControllerFactory();
            factory.RegisterType<IMyService, MyService>();
            ControllerBuilder.Current.SetControllerFactory(factory);
        }
    }
}
