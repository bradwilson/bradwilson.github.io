﻿using System.Web.Mvc;
using TechEd2010.Utility;

namespace TechEd2010.Controllers
{
    public class XmlController : Controller
    {
        public ActionResult Index()
        {
            return new XmlResult(new[] { 4, 8, 15, 16, 23, 42 });
        }
    }
}
