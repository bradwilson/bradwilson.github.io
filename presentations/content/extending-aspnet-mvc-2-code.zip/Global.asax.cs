﻿using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.Web.Mvc.AspNet4;
using TechEd2010.Controllers;

namespace TechEd2010
{
    public class MvcApplication : HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            MethodConstraintController.Initialize(routes);

            routes.MapRoute(
                "Default",
                "{controller}/{action}/{id}",
                new { controller = "Default", action = "Index", id = UrlParameter.Optional }
            );
        }

        protected void Application_Start()
        {
            // Register routes
            AreaRegistration.RegisterAllAreas();
            RegisterRoutes(RouteTable.Routes);

            // Register .NET 4 versions of DataAnnotations metadata and validator providers
            ModelMetadataProviders.Current = new DataAnnotations4ModelMetadataProvider();
            DataAnnotations4ModelValidatorProvider.RegisterProvider();

            AntiXssController.Initialize();
            FluentValidationController.Initialize();
            FluentMetadataController.Initialize();
            PointController.Initialize();
            TempDataValueProviderController.Initialize();
            UnityController.Initialize();
        }
    }
}