﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Diagnostics;

namespace TechEd2010.Utility
{
    public class ActionTimingAttribute : ActionFilterAttribute
    {
        Stopwatch stopwatch;

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            stopwatch = new Stopwatch();
            stopwatch.Start();
            base.OnActionExecuting(filterContext);
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            stopwatch.Stop();
            base.OnActionExecuted(filterContext);
        }

        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            filterContext.HttpContext.Response.Write(String.Format("<!-- Request took {0}ms -->", stopwatch.ElapsedMilliseconds));
            base.OnResultExecuted(filterContext);
        }
    }
}