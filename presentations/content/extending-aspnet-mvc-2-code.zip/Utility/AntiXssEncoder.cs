﻿using System.IO;
using System.Web.Util;
using Microsoft.Security.Application;

namespace TechEd2010.Utility
{
    public class AntiXssEncoder : HttpEncoder
    {
        protected override void HtmlEncode(string value, TextWriter output)
        {
            output.Write(AntiXss.HtmlEncode(value));
        }

        protected override void HtmlAttributeEncode(string value, TextWriter output)
        {
            output.Write(AntiXss.HtmlAttributeEncode(value));
        }
    }
}