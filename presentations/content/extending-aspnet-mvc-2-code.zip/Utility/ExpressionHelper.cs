﻿using System;
using System.Linq.Expressions;

namespace TechEd2010.Utility
{
    public class ExpressionHelper
    {
        public static string ToPropertyName<TType>(Expression<Func<TType, object>> expression)
        {
            Expression body = expression.Body;

            UnaryExpression unaryExpression = body as UnaryExpression;
            if (unaryExpression != null && unaryExpression.NodeType == ExpressionType.Convert)  // Boxing value type to object
                body = unaryExpression.Operand;

            MemberExpression memberExpression = (MemberExpression)body;
            return memberExpression.Member.Name;
        }
    }
}