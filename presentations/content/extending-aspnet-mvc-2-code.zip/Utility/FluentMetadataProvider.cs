﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using System.Web.Mvc;

namespace TechEd2010.Utility
{
    public class FluentMetadataProvider : DataAnnotationsModelMetadataProvider
    {
        ConcurrentDictionary<Tuple<Type, string>, List<Action<ModelMetadata>>> modifiers
            = new ConcurrentDictionary<Tuple<Type, string>, List<Action<ModelMetadata>>>();

        protected override ModelMetadata CreateMetadata(IEnumerable<Attribute> attributes, Type containerType, Func<object> modelAccessor, Type modelType, string propertyName)
        {
            ModelMetadata metadata = base.CreateMetadata(attributes, containerType, modelAccessor, modelType, propertyName);
            Tuple<Type, string> key = propertyName == null ? new Tuple<Type, string>(modelType, null)
                                                           : new Tuple<Type, string>(containerType, propertyName);

            List<Action<ModelMetadata>> modifierList;
            if (modifiers.TryGetValue(key, out modifierList))
                foreach (Action<ModelMetadata> modifier in modifierList)
                    modifier(metadata);

            return metadata;
        }

        private void Add(Type type, string propertyName, Action<ModelMetadata> modifier)
        {
            modifiers.GetOrAdd(
                new Tuple<Type, string>(type, propertyName),
                _ => new List<Action<ModelMetadata>>()
            ).Add(modifier);
        }

        public MetadataRegistrar ForType<TType>()
        {
            return new MetadataRegistrar(this, typeof(TType), null);
        }

        public MetadataRegistrar ForProperty<TType>(Expression<Func<TType, object>> expression)
        {
            return new MetadataRegistrar(this, typeof(TType), ExpressionHelper.ToPropertyName(expression));
        }

        public class MetadataRegistrar
        {
            FluentMetadataProvider provider;
            Type type;
            string propertyName;

            public MetadataRegistrar(FluentMetadataProvider provider, Type type, string propertyName)
            {
                this.provider = provider;
                this.type = type;
                this.propertyName = propertyName;
            }

            public MetadataRegistrar ConvertEmptyStringToNull(bool convertEmptyStringToNull)
            {
                provider.Add(type, propertyName, metadata => metadata.ConvertEmptyStringToNull = convertEmptyStringToNull);
                return this;
            }

            public MetadataRegistrar DataTypeName(string dataTypeName)
            {
                provider.Add(type, propertyName, metadata => metadata.DataTypeName = dataTypeName);
                return this;
            }

            public MetadataRegistrar Description(string description)
            {
                provider.Add(type, propertyName, metadata => metadata.Description = description);
                return this;
            }

            public MetadataRegistrar DisplayFormatString(string displayFormatString)
            {
                provider.Add(type, propertyName, metadata => metadata.DisplayFormatString = displayFormatString);
                return this;
            }

            public MetadataRegistrar DisplayName(string displayName)
            {
                provider.Add(type, propertyName, metadata => metadata.DisplayName = displayName);
                return this;
            }

            public MetadataRegistrar EditFormatString(string editFormatString)
            {
                provider.Add(type, propertyName, metadata => metadata.EditFormatString = editFormatString);
                return this;
            }

            public MetadataRegistrar HideSurroundingHtml(bool hideSurroundingHtml)
            {
                provider.Add(type, propertyName, metadata => metadata.HideSurroundingHtml = hideSurroundingHtml);
                return this;
            }

            public MetadataRegistrar IsReadOnly(bool isReadOnly)
            {
                provider.Add(type, propertyName, metadata => metadata.IsReadOnly = isReadOnly);
                return this;
            }

            public MetadataRegistrar NullDisplayText(string nullDisplayText)
            {
                provider.Add(type, propertyName, metadata => metadata.NullDisplayText = nullDisplayText);
                return this;
            }

            public MetadataRegistrar ShortDisplayName(string shortDisplayName)
            {
                provider.Add(type, propertyName, metadata => metadata.ShortDisplayName = shortDisplayName);
                return this;
            }

            public MetadataRegistrar ShowForDisplay(bool showForDisplay)
            {
                provider.Add(type, propertyName, metadata => metadata.ShowForDisplay = showForDisplay);
                return this;
            }

            public MetadataRegistrar ShowForEdit(bool showForEdit)
            {
                provider.Add(type, propertyName, metadata => metadata.ShowForEdit = showForEdit);
                return this;
            }

            public MetadataRegistrar SimpleDisplayText(string simpleDisplayText)
            {
                provider.Add(type, propertyName, metadata => metadata.SimpleDisplayText = simpleDisplayText);
                return this;
            }

            public MetadataRegistrar TemplateHint(string templateHint)
            {
                provider.Add(type, propertyName, metadata => metadata.TemplateHint = templateHint);
                return this;
            }

            public MetadataRegistrar Watermark(string watermark)
            {
                provider.Add(type, propertyName, metadata => metadata.Watermark = watermark);
                return this;
            }
        }
    }
}