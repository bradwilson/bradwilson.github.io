﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Linq;

namespace TechEd2010.Utility
{
    public class FluentValidationProvider : ModelValidatorProvider
    {
        delegate ModelValidator ValidatorFactory(ModelMetadata metadata, ControllerContext context);

        ConcurrentDictionary<Tuple<Type, string>, List<ValidatorFactory>> validators = new ConcurrentDictionary<Tuple<Type, string>, List<ValidatorFactory>>();

        private void Add(Type type, string propertyName, ValidatorFactory factory)
        {
            validators.GetOrAdd(
                new Tuple<Type, string>(type, propertyName),
                _ => new List<ValidatorFactory>()
            ).Add(factory);
        }

        public ValidatorRegistrar ForType<TType>()
        {
            return new ValidatorRegistrar(this, typeof(TType), null);
        }

        public ValidatorRegistrar ForProperty<TType>(Expression<Func<TType, object>> expression)
        {
            return new ValidatorRegistrar(this, typeof(TType), ExpressionHelper.ToPropertyName(expression));
        }

        public override IEnumerable<ModelValidator> GetValidators(ModelMetadata metadata, ControllerContext context)
        {
            IEnumerable<ModelValidator> results = Enumerable.Empty<ModelValidator>();
            if (metadata.PropertyName != null)
                results = GetValidators(metadata, context, metadata.ContainerType, metadata.PropertyName);

            return results.Concat(GetValidators(metadata, context, metadata.ModelType));
        }

        private IEnumerable<ModelValidator> GetValidators(ModelMetadata metadata, ControllerContext context, Type type, string propertyName = null)
        {
            Tuple<Type, string> key = new Tuple<Type, string>(type, propertyName);
            List<ValidatorFactory> factories;
            if (validators.TryGetValue(key, out factories))
                foreach (var factory in factories)
                    yield return factory(metadata, context);
        }

        public class ValidatorRegistrar
        {
            private FluentValidationProvider fluentValidator;
            private string propertyName;
            private Type type;

            public ValidatorRegistrar(FluentValidationProvider fluentValidator, Type type, string propertyName)
            {
                this.fluentValidator = fluentValidator;
                this.type = type;
                this.propertyName = propertyName;
            }

            public ValidatorRegistrar Range<T>(T minimum, T maximum, string errorMessage = null)
            {
                RangeAttribute attribute = new RangeAttribute(typeof(T), minimum.ToString(), maximum.ToString());
                if (errorMessage != null)
                    attribute.ErrorMessage = errorMessage;

                fluentValidator.Add(
                    type,
                    propertyName,
                    (metadata, context) => new RangeAttributeAdapter(metadata, context, attribute)
                );

                return this;
            }

            public ValidatorRegistrar Regex(string pattern, string errorMessage = null)
            {
                RegularExpressionAttribute attribute = new RegularExpressionAttribute(pattern);
                if (errorMessage != null)
                    attribute.ErrorMessage = errorMessage;

                fluentValidator.Add(
                    type,
                    propertyName,
                    (metadata, context) => new RegularExpressionAttributeAdapter(metadata, context, attribute)
                );

                return this;
            }

            public ValidatorRegistrar Required(string errorMessage = null)
            {
                RequiredAttribute attribute = new RequiredAttribute();
                if (errorMessage != null)
                    attribute.ErrorMessage = errorMessage;

                fluentValidator.Add(
                    type,
                    propertyName,
                    (metadata, context) => new RequiredAttributeAdapter(metadata, context, attribute)
                );

                return this;
            }

            public ValidatorRegistrar StringLength(int minLength = 0, int maxLength = Int32.MaxValue, string errorMessage = null)
            {
                StringLengthAttribute attribute = new StringLengthAttribute(maxLength) { MinimumLength = minLength };
                if (errorMessage != null)
                    attribute.ErrorMessage = errorMessage;

                fluentValidator.Add(
                    type,
                    propertyName,
                    (metadata, context) => new StringLengthAttributeAdapter(metadata, context, attribute)
                );

                return this;
            }
        }
    }
}