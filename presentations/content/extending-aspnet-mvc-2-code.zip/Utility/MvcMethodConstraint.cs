﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace TechEd2010.Utility
{
    public class MvcMethodConstraint : IRouteConstraint
    {
        public MvcMethodConstraint(params string[] allowedMethods)
        {
            if (allowedMethods == null)
                throw new ArgumentNullException("allowedMethods");

            AllowedMethods = allowedMethods.ToList();
        }

        public List<string> AllowedMethods { get; private set; }

        public bool Match(HttpContextBase httpContext, Route route, string parameterName,
                          RouteValueDictionary values, RouteDirection routeDirection)
        {
            switch (routeDirection)
            {
                case RouteDirection.IncomingRequest:
                    string httpMethodOverride = httpContext.Request.GetHttpMethodOverride();
                    return AllowedMethods.Contains(httpMethodOverride, StringComparer.OrdinalIgnoreCase);

                case RouteDirection.UrlGeneration:
                    object paramValue;
                    if (values.TryGetValue(parameterName, out paramValue))
                        return AllowedMethods.Contains((string)paramValue, StringComparer.OrdinalIgnoreCase);
                    break;
            }

            return true;
        }

        public override string ToString()
        {
            return AllowedMethods.Aggregate((left, right) => left + ", " + right);
        }
    }
}