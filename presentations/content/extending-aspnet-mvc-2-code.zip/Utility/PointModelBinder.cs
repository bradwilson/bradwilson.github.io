﻿using System.Drawing;
using System.Web.Mvc;

namespace TechEd2010.Utility
{
    public class PointModelBinder : IModelBinder
    {
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            int x = (int)bindingContext.ValueProvider.GetValue("X").ConvertTo(typeof(int));
            int y = (int)bindingContext.ValueProvider.GetValue("Y").ConvertTo(typeof(int));
            return new Point(x, y);
        }
    }
}