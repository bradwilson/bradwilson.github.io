﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Microsoft.Web.Mvc.AspNet4;

namespace TechEd2010.Utility
{
    public class PriceAttribute : ValidationAttribute, IClientValidatable
    {
        public double MinPrice { get; set; }

        public override bool IsValid(object value)
        {
            if (value == null)
            {
                return true;
            }

            var price = (double)value;
            if (price < MinPrice)
            {
                return false;
            }

            double cents = price - Math.Floor(price);
            if (cents < 0.99 || cents >= 0.995)
            {
                return false;
            }

            return true;
        }

        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            var rule = new ModelClientValidationRule
            {
                ErrorMessage = FormatErrorMessage("price"),
                ValidationType = "price"
            };

            rule.ValidationParameters.Add("min", MinPrice);
            yield return rule;
        }
    }
}
