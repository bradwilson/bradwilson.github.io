﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Web.Mvc;

namespace TechEd2010.Utility
{
    public class TempDataValueProviderFactory : ValueProviderFactory
    {
        public override IValueProvider GetValueProvider(ControllerContext controllerContext)
        {
            TempDataDictionary tempData = controllerContext.Controller.TempData;
            if (tempData.Count == 0)
                return null;

            return new TempDataValueProvider(tempData);
        }

        private sealed class TempDataValueProvider : DictionaryValueProvider<TempDataVoid>
        {
            private readonly TempDataDictionary _tempData;

            public TempDataValueProvider(TempDataDictionary tempData)
                : base(GetVoidDictionary(tempData), CultureInfo.InvariantCulture)
            {
                _tempData = tempData;
            }

            public override ValueProviderResult GetValue(string key)
            {
                object rawValue;

                if (_tempData.TryGetValue(key, out rawValue))
                {
                    string attemptedValue = Convert.ToString(rawValue, CultureInfo.InvariantCulture);
                    return new ValueProviderResult(rawValue, attemptedValue, CultureInfo.InvariantCulture);
                }

                return null;
            }

            private static Dictionary<string, TempDataVoid> GetVoidDictionary(TempDataDictionary tempData)
            {
                Dictionary<string, TempDataVoid> d = new Dictionary<string, TempDataVoid>(StringComparer.OrdinalIgnoreCase);

                foreach (string key in tempData.Keys)  // foreach won't mark things for removal
                    d[key] = default(TempDataVoid);

                return d;
            }
        }

        private struct TempDataVoid { }
    }
}
