﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;

public static class TypeUtility
{
    private static readonly string[] _controllers =
        Assembly.GetExecutingAssembly()
                .GetExportedTypes()
                .Where(t => (t.Namespace ?? "").StartsWith("TechEd2010.Controllers"))
                .Where(t => t.Name.EndsWith("Controller"))
                .Select(t => t.Name.Substring(0, t.Name.Length - 10))
                .Where(c => c != "Default")
                .OrderBy(c => c)
                .ToArray();

    public static IEnumerable<string> Controllers
    {
        get { return _controllers; }
    }
}
