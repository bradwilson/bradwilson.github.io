﻿using System;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.Practices.Unity;

namespace TechEd2010.Utility
{
    public class UnityControllerFactory : DefaultControllerFactory
    {
        UnityContainer container = new UnityContainer();
        PerResolveLifetimeManager lifetimeManager = new PerResolveLifetimeManager();

        protected override IController GetControllerInstance(RequestContext requestContext, Type controllerType)
        {
            if (controllerType == null)    // controllerType will be null when we don't know what type it is
                return base.GetControllerInstance(requestContext, controllerType);

            return (IController)container.Resolve(controllerType);
        }

        public override void ReleaseController(IController controller)
        {
            container.Teardown(controller);
        }

        public void RegisterType<TFrom, TTo>()
        {
            container.RegisterType(typeof(TFrom), typeof(TTo), null, lifetimeManager, new InjectionMember[0]);
        }

    }
}