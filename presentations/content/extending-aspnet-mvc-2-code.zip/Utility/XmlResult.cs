﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml.Serialization;

namespace TechEd2010.Utility
{
    public class XmlResult : ActionResult
    {
        object model;

        public XmlResult(object model)
        {
            this.model = model;
        }

        public override void ExecuteResult(ControllerContext context)
        {
            XmlSerializer serializer = new XmlSerializer(model.GetType());
            context.HttpContext.Response.ContentType = "text/xml";
            serializer.Serialize(context.HttpContext.Response.OutputStream, model);
        }
    }
}