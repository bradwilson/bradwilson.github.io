﻿using System.Collections.Generic;
using System.Linq;
using Moq;
using Xunit;

public class BillingProcessorTests
{
    public class NoSubscription
    {
        [Fact]
        public void CustomerWhoDoesNotHaveSubscriptionDoesNotGetCharged()
        {
            var customer = new Customer();
            var processor = TestableBillingProcessor.Create(customer);

            processor.ProcessMonth(2011, 8);

            processor.Charger.Verify(c => c.ChargeCustomer(customer), Times.Never());
        }
    }

    public class Monthly
    {
        [Fact]
        public void CustomerWithSubscriptionThatIsExpiredGetsCharged()
        {
            var subscription = new MonthlySubscription();
            var customer = new Customer { Subscription = subscription };
            var processor = TestableBillingProcessor.Create(customer);

            processor.ProcessMonth(2011, 8);

            processor.Charger.Verify(c => c.ChargeCustomer(customer), Times.Once());
        }

        [Fact]
        public void CustomerWithSubscriptionThatIsCurrentDoesNotGetCharged()
        {
            var subscription = new MonthlySubscription { PaidThroughYear = 2011, PaidThroughMonth = 8 };
            var customer = new Customer { Subscription = subscription };
            var processor = TestableBillingProcessor.Create(customer);

            processor.ProcessMonth(2011, 8);

            processor.Charger.Verify(c => c.ChargeCustomer(customer), Times.Never());
        }

        [Fact]
        public void CustomerWithSubscriptionThatIsCurrentThroughNextYearDoesNotGetCharged()
        {
            var subscription = new MonthlySubscription { PaidThroughYear = 2012, PaidThroughMonth = 1 };
            var customer = new Customer { Subscription = subscription };
            var processor = TestableBillingProcessor.Create(customer);

            processor.ProcessMonth(2011, 8);

            processor.Charger.Verify(c => c.ChargeCustomer(customer), Times.Never());
        }

        [Fact]
        public void CustomerWhoIsSubscribedAndDueToPayButFailsOnceIsStillCurrent()
        {
            var subscription = new MonthlySubscription();
            var customer = new Customer { Subscription = subscription };
            var processor = TestableBillingProcessor.Create(customer);
            processor.Charger.Setup(c => c.ChargeCustomer(It.IsAny<Customer>()))
                             .Returns(false);

            processor.ProcessMonth(2011, 8);

            Assert.True(customer.Subscription.IsCurrent);
        }

        [Fact]
        public void CustomerWhoIsSubscribedAndDueToPayButFailsMaximumTimesIsNoLongerSubscribed()
        {
            var subscription = new MonthlySubscription();
            var customer = new Customer { Subscription = subscription };
            var processor = TestableBillingProcessor.Create(customer);
            processor.Charger.Setup(c => c.ChargeCustomer(It.IsAny<Customer>()))
                             .Returns(false);

            for (int i = 0; i < MonthlySubscription.MAX_FAILURES; i++)
                processor.ProcessMonth(2011, 8);

            Assert.False(customer.Subscription.IsCurrent);
        }
    }

    public class Annual
    {
    }

    // Grace period for missed payments ("dunning" status)
    // Not all customers are necessarily subscribers
    // Idle customers should be automatically unsubscribed
    // What about customers who sign up today?
}

public interface ICustomerRepository
{
    IEnumerable<Customer> Customers { get; }
}

public interface ICreditCardCharger
{
    bool ChargeCustomer(Customer customer);
}

public abstract class Subscription
{
    public abstract bool IsCurrent { get; }
    public abstract bool IsRecurring { get; }

    public abstract bool NeedsBilling(int year, int month);

    public virtual void RecordChargeResult(bool charged)
    {
    }
}

public class AnnualSubscription : Subscription
{
    public override bool IsCurrent
    {
        get { throw new System.NotImplementedException(); }
    }

    public override bool IsRecurring
    {
        get { return false; }
    }

    public override bool NeedsBilling(int year, int month)
    {
        throw new System.NotImplementedException();
    }
}

public class MonthlySubscription : Subscription
{
    public const int MAX_FAILURES = 3;

    private int failureCounter;

    public override bool IsCurrent
    {
        get
        {
            return failureCounter < MAX_FAILURES;
        }
    }

    public override bool IsRecurring
    {
        get { return true; }
    }

    public int PaidThroughMonth { get; set; }
    public int PaidThroughYear { get; set; }

    public override bool NeedsBilling(int year, int month)
    {
        return PaidThroughYear <= year &&
               PaidThroughMonth < month;
    }

    public override void RecordChargeResult(bool charged)
    {
        if (!charged)
            failureCounter++;
    }
}

public class Customer
{
    // Is this really customer data? or subscription data?
    //public int PaymentFailures { get; set; }
    //public bool Subscribed { get; set; }

    public Subscription Subscription { get; set; }
}

public class BillingProcessor
{
    ICreditCardCharger charger;
    ICustomerRepository repo;

    public BillingProcessor(ICustomerRepository repo, ICreditCardCharger charger)
    {
        this.repo = repo;
        this.charger = charger;
    }

    public void ProcessMonth(int year, int month)
    {
        var customer = repo.Customers.Single();

        if (NeedsBilling(year, month, customer))
        {
            bool charged = charger.ChargeCustomer(customer);
            customer.Subscription.RecordChargeResult(charged);
        }
    }

    private static bool NeedsBilling(int year, int month, Customer customer)
    {
        return customer.Subscription != null
            && customer.Subscription.NeedsBilling(year, month);
    }
}

public class TestableBillingProcessor : BillingProcessor
{
    public Mock<ICreditCardCharger> Charger;
    public Mock<ICustomerRepository> Repository;

    TestableBillingProcessor(Mock<ICustomerRepository> repository,
                             Mock<ICreditCardCharger> charger)
        : base(repository.Object, charger.Object)
    {
        Charger = charger;
        Repository = repository;
    }

    public static TestableBillingProcessor Create(params Customer[] customers)
    {
        Mock<ICustomerRepository> repository = new Mock<ICustomerRepository>();
        repository.Setup(r => r.Customers)
                  .Returns(customers);

        return new TestableBillingProcessor(
            repository,
            new Mock<ICreditCardCharger>()
        );
    }
}
