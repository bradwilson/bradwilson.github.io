﻿using System.Web.Mvc;
using AdvancedMVC.Areas.CustomValidationDemo.Models;

namespace AdvancedMVC.Areas.CustomValidationDemo.Controllers
{
    public class ValidationController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(ProductViewModel model)
        {
            return View(model);
        }
    }
}
