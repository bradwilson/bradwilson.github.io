﻿using System.Web.Mvc;
using AdvancedMVC.Areas.CustomValidationDemo.Validators;
using Microsoft.Web.Mvc.AspNet4;

namespace AdvancedMVC.Areas.CustomValidationDemo
{
    public class CustomValidationDemoAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "CustomValidationDemo"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "CustomValidationDemo_default",
                "CustomValidationDemo/{action}",
                new { controller = "Validation", action = "Index" }
            );

            DataAnnotations4ModelValidatorProvider.RegisterAdapter(
                typeof(PriceAttribute),
                typeof(PriceValidator)
            );
        }
    }
}
