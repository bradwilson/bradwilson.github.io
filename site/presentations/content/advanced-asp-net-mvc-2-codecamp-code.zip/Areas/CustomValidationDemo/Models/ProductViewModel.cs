﻿using System.ComponentModel.DataAnnotations;
using AdvancedMVC.Areas.CustomValidationDemo.Validators;

namespace AdvancedMVC.Areas.CustomValidationDemo.Models
{
    public class ProductViewModel
    {
        [Required]
        public string Title { get; set; }

        [Required]
        [Price(MinPrice = 3.99, ErrorMessage = "Price must end in .99 and be larger than 3.99")]
        public double Price { get; set; }
    }
}
