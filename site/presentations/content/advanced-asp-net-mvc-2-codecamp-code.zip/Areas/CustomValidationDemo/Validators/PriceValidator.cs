﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace AdvancedMVC.Areas.CustomValidationDemo.Validators
{
    public class PriceValidator : DataAnnotationsModelValidator<PriceAttribute>
    {
        public PriceValidator(ModelMetadata metadata,
                              ControllerContext context,
                              PriceAttribute attribute)
            : base(metadata, context, attribute) { }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules()
        {
            var rule = new ModelClientValidationRule
            {
                ErrorMessage = Attribute.FormatErrorMessage("price"),
                ValidationType = "price"
            };

            rule.ValidationParameters.Add("min", Attribute.MinPrice);
            yield return rule;
        }
    }
}