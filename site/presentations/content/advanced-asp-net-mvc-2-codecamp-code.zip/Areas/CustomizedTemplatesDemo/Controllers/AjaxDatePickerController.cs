﻿using System.Web.Mvc;
using AdvancedMVC.Areas.CustomizedTemplatesDemo.Models;

namespace AdvancedMVC.Areas.CustomizedTemplatesDemo.Controllers
{
    public class AjaxDatePickerController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(EventModel myEvent)
        {
            return View(myEvent);
        }
    }
}
