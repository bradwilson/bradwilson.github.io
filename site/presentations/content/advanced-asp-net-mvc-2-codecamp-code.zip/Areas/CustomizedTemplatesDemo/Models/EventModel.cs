﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AdvancedMVC.Areas.CustomizedTemplatesDemo.Models
{
    public class EventModel
    {
        [Required]
        [Display(Name = "Event Name")]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }

        [Required]
        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }
    }
}