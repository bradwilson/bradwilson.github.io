﻿using System.Web.Mvc;

namespace AdvancedMVC.Areas.HttpMethodDemo.Controllers
{
    public class HttpMethodController : Controller
    {
        public ActionResult Index()
        {
            ViewData["Message"] = "Hello from the default action";
            return View();
        }

        [HttpPut]
        public ActionResult Index(string unused)
        {
            ViewData["Message"] = "Hello from the PUT action";
            return View();
        }
    }
}
