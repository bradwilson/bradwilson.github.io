﻿using System.Web.Mvc;

namespace AdvancedMVC.Areas.HttpMethodDemo
{
    public class HttpMethodDemoAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "HttpMethodDemo"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "HttpMethodDemo_Default",
                "HttpMethodDemo/{controller}/{action}/{id}",
                new { action = "index", id = UrlParameter.Optional }
            );
        }
    }
}
