﻿using System.Linq;
using AdvancedMVC.Areas.RestResourceDemo.Models;

namespace AdvancedMVC.Areas.RestResourceDemo.Controllers
{
    public class PeopleController : ResourceController<Person, int>
    {
        PersonRepository repository = new PersonRepository();

        protected override int AddModel(Person person)
        {
            repository.Add(person);
            return person.Id;
        }

        protected override void DeleteModel(int id)
        {
            repository.Delete(id);
        }

        protected override IQueryable<Person> GetAllModels()
        {
            return repository.All.OrderBy(p => p.FullName);
        }

        protected override Person GetModelById(int id)
        {
            return repository.Get(id);
        }

        protected override string GetModelDisplayText(Person person)
        {
            return person.FullName;
        }

        protected override void UpdateModel(int id, Person person)
        {
            repository.Update(person);
        }
    }
}
