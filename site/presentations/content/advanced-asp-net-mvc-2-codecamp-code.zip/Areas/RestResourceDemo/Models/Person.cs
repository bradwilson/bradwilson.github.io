﻿using System.ComponentModel.DataAnnotations;

namespace AdvancedMVC.Areas.RestResourceDemo.Models
{
    public class Person
    {
        [ScaffoldColumn(false)]
        public int Id { get; set; }

        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [ScaffoldColumn(false)]
        public string FullName { get { return FirstName + " " + LastName; } }
    }
}