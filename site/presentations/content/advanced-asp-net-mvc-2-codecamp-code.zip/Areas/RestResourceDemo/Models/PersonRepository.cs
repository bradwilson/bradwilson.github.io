﻿using System.Collections.Generic;
using System.Linq;

namespace AdvancedMVC.Areas.RestResourceDemo.Models
{
    public class PersonRepository
    {
        static List<Person> people = new List<Person>
        {
            new Person { Id = 1, FirstName = "Brad", LastName = "Wilson" },
            new Person { Id = 2, FirstName = "Scott", LastName = "Guthrie" },
            new Person { Id = 3, FirstName = "Scott", LastName = "Hanselman" },
            new Person { Id = 4, FirstName = "Phil", LastName = "Haack" },
        };

        static int nextId = 5;

        public IQueryable<Person> All
        {
            get { return people.AsQueryable(); }
        }

        public Person Get(int id)
        {
            return (from person in people
                    where person.Id == id
                    select person).FirstOrDefault();
        }

        public void Add(Person person)
        {
            person.Id = nextId++;

            people.Add(new Person
            {
                Id = person.Id,
                FirstName = person.FirstName,
                LastName = person.LastName
            });
        }

        public void Update(Person person)
        {
            Person toUpdate = Get(person.Id);

            if (toUpdate != null)
            {
                toUpdate.FirstName = person.FirstName;
                toUpdate.LastName = person.LastName;
            }
        }

        public void Delete(int id)
        {
            people.RemoveAll(p => p.Id == id);
        }
    }
}
