﻿using System.Web.Mvc;

namespace AdvancedMVC.Areas.RestResourceDemo
{
    public class RestResourceDemoAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "RestResourceDemo"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapResourceRoutes("RestResourceDemo/people");
        }
    }
}
