﻿using System.IO;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Routing;
using System.Xml.Serialization;

public abstract class ResourceController<TModel, TKey> : Controller
{
    // Overrides

    protected abstract TKey AddModel(TModel model);

    protected abstract void DeleteModel(TKey id);

    protected abstract IQueryable<TModel> GetAllModels();

    protected abstract TModel GetModelById(TKey id);

    protected virtual string GetModelDisplayText(TModel model)
    {
        return null;
    }

    protected abstract void UpdateModel(TKey id, TModel model);

    // GET /{plural}

    public ActionResult List()
    {
        return View(GetAllModels());
    }

    // GET /{plural}.json

    public ActionResult ListJson()
    {
        return Json(GetAllModels(), JsonRequestBehavior.AllowGet);
    }

    // GET /{plural}.xml

    public ActionResult ListXml()
    {
        return Xml(GetAllModels().ToArray());
    }

    // GET /{plural}/new

    public ActionResult New()
    {
        return View();
    }

    // PUT /{plural}

    public ActionResult Insert(TModel model)
    {
        if (ModelState.IsValid)
        {
            TKey id = AddModel(model);
            TempData["flash"] = (GetModelDisplayText(model) ?? "Item") + " has been created.";
            return RedirectToAction("Details", new { id });
        }

        SaveModelState();
        return RedirectToAction("New");
    }

    // GET /{singular}/{id}

    public ActionResult Details(TKey id)
    {
        TModel model = GetModelById(id);
        if (model == null)
            return RedirectToAction("List");

        return View(model);
    }

    // GET /{singular}/{id}.json

    public ActionResult DetailsJson(TKey id)
    {
        TModel model = GetModelById(id);
        if (model == null)
            return RedirectToAction("List");

        return Json(model, JsonRequestBehavior.AllowGet);
    }

    // GET /{singular}/{id}.xml

    public ActionResult DetailsXml(TKey id)
    {
        TModel model = GetModelById(id);
        if (model == null)
            return RedirectToAction("List");

        return Xml(model);
    }

    // GET /{singular}/{id}/edit

    public ActionResult Edit(TKey id)
    {
        TModel model = GetModelById(id);
        if (model == null)
            return RedirectToAction("List");

        return View(model);
    }

    // POST /{singular}/{id}

    public ActionResult Update(TKey id, TModel model)
    {
        if (ModelState.IsValid)
        {
            UpdateModel(id, model);
            TempData["flash"] = (GetModelDisplayText(model) ?? "Item") + " has been saved.";
            return RedirectToAction("Details");
        }

        SaveModelState();
        return RedirectToAction("Edit", new { id });
    }

    // DELETE /{singular}/{id}

    public ActionResult Delete(TKey id)
    {
        TModel model = GetModelById(id);
        if (model != null)
        {
            string displayText = GetModelDisplayText(model) ?? "Item";
            DeleteModel(id);
            TempData["flash"] = displayText + " has been deleted.";
        }

        return RedirectToAction("List");
    }

    // Model state preservation helpers

    protected override void Initialize(RequestContext requestContext)
    {
        base.Initialize(requestContext);

        RestoreModelState();
    }

    protected void SaveModelState()
    {
        TempData["ModelState"] = ModelState;
    }

    protected void RestoreModelState()
    {
        ModelStateDictionary modelState = TempData["ModelState"] as ModelStateDictionary;
        if (modelState != null)
            ModelState.Merge(modelState);
    }

    protected ActionResult Xml(object model)
    {
        XmlSerializer serializer = new XmlSerializer(model.GetType());
        StringWriter writer = new StringWriter();
        serializer.Serialize(writer, model);
        return Content(writer.ToString(), "text/xml");
    }
}
