﻿using System;
using System.Linq;
using System.Web.Mvc;

public static class ResourceRouteExtensions
{
    public static void MapResourceRoutes(this AreaRegistrationContext context,
                                         string url)
    {
        url = url.Trim('/');
        string controller = url.Split('/').Last();

        // ------------------------
        //  Collection URLs

        // GET {url}.json        [retrieves a list of objects, as JSON]

        context.MapRoute(
            context.AreaName + "_ListJson_" + controller,
            url + ".json",
            new { controller = controller, action = "ListJson" },
            new { httpMethod = new MvcMethodConstraint("GET") }
        );

        // GET {url}.xml        [retrieves a list of objects, as XML]

        context.MapRoute(
            context.AreaName + "_ListXml_" + controller,
            url + ".xml",
            new { controller = controller, action = "ListXml" },
            new { httpMethod = new MvcMethodConstraint("GET") }
        );

        // GET {url}        [retrieves a list of objects, as HTML]

        context.MapRoute(
            context.AreaName + "_List_" + controller,
            url,
            new { controller = controller, action = "List" },
            new { httpMethod = new MvcMethodConstraint("GET") }
        );

        // PUT {url}        [inserts a new object]

        context.MapRoute(
            context.AreaName + "_Insert_" + controller,
            url,
            new { controller = controller, action = "Insert" },
            new { httpMethod = new MvcMethodConstraint("PUT") }
        );

        // GET {url}/new        [gets a form for inserting a new object]

        context.MapRoute(
            context.AreaName + "_New_" + controller,
            url + "/new",
            new { controller = controller, action = "New" },
            new { httpMethod = new MvcMethodConstraint("GET") }
        );

        // ------------------------
        //  Item URLs

        string itemUrl = url + "/{id}";

        // GET {url}/{id}.json        [gets a single item as JSON]

        context.MapRoute(
            context.AreaName + "_DetailsJson_" + controller,
            itemUrl + ".json",
            new { controller = controller, action = "DetailsJson" },
            new { httpMethod = new MvcMethodConstraint("GET") }
        );

        // GET {url}/{id}.xml        [gets a single item as XML]

        context.MapRoute(
            context.AreaName + "_DetailsXml_" + controller,
            itemUrl + ".xml",
            new { controller = controller, action = "DetailsXml" },
            new { httpMethod = new MvcMethodConstraint("GET") }
        );

        // GET {url}/{id}        [gets a single item as HTML]

        context.MapRoute(
            context.AreaName + "_Details_" + controller,
            itemUrl,
            new { controller = controller, action = "Details" },
            new { httpMethod = new MvcMethodConstraint("GET") }
        );

        // POST {url}/{id}        [updates a single item as JSON]

        context.MapRoute(
            context.AreaName + "_Update_" + controller,
            itemUrl,
            new { controller = controller, action = "Update" },
            new { httpMethod = new MvcMethodConstraint("POST") }
        );

        // GET {url}/{id}/edit        [gets a form for editing an existing object]

        context.MapRoute(
            context.AreaName + "_Edit_" + controller,
            itemUrl + "/edit",
            new { controller = controller, action = "Edit" },
            new { httpMethod = new MvcMethodConstraint("GET") }
        );

        // DELETE {url}/{id}        [deletes a single item]

        context.MapRoute(
            context.AreaName + "_Delete_" + controller,
            itemUrl,
            new { controller = controller, action = "Delete" },
            new { httpMethod = new MvcMethodConstraint("DELETE") }
        );
    }

    private static string Normalize(string urlPrefix)
    {
        if (String.IsNullOrWhiteSpace(urlPrefix))
            return String.Empty;

        return urlPrefix.TrimEnd('/') + "/";
    }
}
