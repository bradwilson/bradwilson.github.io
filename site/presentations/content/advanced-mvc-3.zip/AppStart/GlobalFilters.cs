﻿using System.Web.Mvc;
using WebActivator;

[assembly: PreApplicationStartMethod(typeof(MvcConf2011.AppStart.GlobalFilters), "Start")]

namespace MvcConf2011.AppStart
{
    public static class GlobalFilters
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public static void Start()
        {
            RegisterGlobalFilters(System.Web.Mvc.GlobalFilters.Filters);
        }
    }
}