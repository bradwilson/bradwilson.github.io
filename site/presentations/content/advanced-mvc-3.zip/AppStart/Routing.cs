﻿using System;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Routing;
using MvcConf2011.AppStart;
using WebActivator;

[assembly: PreApplicationStartMethod(typeof(Routing), "Start")]

namespace MvcConf2011.AppStart
{
    public static class Routing
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
        }

        public static void Start()
        {
            RegisterAllAreas();
            RegisterRoutes(RouteTable.Routes);
        }

        #region Dragons! (aka, re-impl of RegisterAllAreas)

        static void RegisterAllAreas()
        {
            // Can't run AreaRegistration.RegisterAllAreas() during app pre-start, so we'll run
            // the moral equivalent

            var initializeMethod = typeof(AreaRegistration).GetMethod("CreateContextAndRegister", BindingFlags.NonPublic | BindingFlags.Instance);

            var areaRegistrationTypes =
                from type in Assembly.GetExecutingAssembly().GetTypes()
                where typeof(AreaRegistration).IsAssignableFrom(type)
                   && type.GetConstructor(Type.EmptyTypes) != null
                select type;

            foreach (Type areaRegistrationType in areaRegistrationTypes)
            {
                var areaRegistration = Activator.CreateInstance(areaRegistrationType);
                initializeMethod.Invoke(areaRegistration, new[] { RouteTable.Routes, null });
            }
        }

        #endregion
    }
}