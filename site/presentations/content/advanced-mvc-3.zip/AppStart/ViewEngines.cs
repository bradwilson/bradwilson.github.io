﻿using System.Web.Mvc;
using WebActivator;

[assembly: PreApplicationStartMethod(typeof(MvcConf2011.AppStart.ViewEngines), "Start")]

namespace MvcConf2011.AppStart
{
    public static class ViewEngines
    {
        public static void RegisterViewEngines(ViewEngineCollection viewEngines)
        {
            var areaFormats = new[] { "~/Areas/{2}/Views/{1}/{0}.cshtml" };
            var viewFormats = new[] { "~/Views/{1}/{0}.cshtml" };
            var razorViewEngine = new RazorViewEngine
            {
                AreaViewLocationFormats = areaFormats,
                AreaMasterLocationFormats = areaFormats,
                AreaPartialViewLocationFormats = areaFormats,
                ViewLocationFormats = viewFormats,
                MasterLocationFormats = viewFormats,
                PartialViewLocationFormats = viewFormats,
            };

            viewEngines.Clear();
            viewEngines.Add(razorViewEngine);
        }

        public static void Start()
        {
            RegisterViewEngines(System.Web.Mvc.ViewEngines.Engines);
        }
    }
}