﻿using System.Web.Mvc;

namespace MvcConf2011.Areas.AsyncTwitterSearch
{
    public class AsyncTwitterSearchAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "AsyncTwitterSearch"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "AsyncTwitterSearch",
                "AsyncTwitterSearch/{action}",
                new { controller = "AsyncTwitterSearch", action = "Index" }
            );
        }
    }
}