﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using MvcConf2011.Areas.StatefulFilters.Utility;
using MvcConf2011.Properties;

namespace MvcConf2011.Areas.AsyncTwitterSearch.Controllers
{
    public class Tweet
    {
        public string Username { get; set; }
        public IHtmlString Html { get; set; }
        public DateTime Date { get; set; }
    }

    [RequestTimingFilter]
    public class AsyncTwitterSearchController : AsyncController
    {
        static string[] searchTerms = new[] { "mvcconf", "aspnetmvc", "@bradwilson", "@scottgu" };

        public ActionResult Sync()
        {
            List<Tweet> tweets = new List<Tweet>();

            foreach (var searchTerm in searchTerms)
                tweets.AddRange(new TwitterSearch().Search(searchTerm));

            return View("Results", tweets.OrderByDescending(t => t.Date));
        }

        public void AsyncAsync()
        {
            List<Tweet> results = new List<Tweet>();
            AsyncManager.Parameters["results"] = results;

            foreach (var searchTerm in searchTerms)
            {
                AsyncManager.OutstandingOperations.Increment();
                TwitterSearch search = new TwitterSearch();

                search.SearchCompleted += (sender, e) =>
                {
                    AsyncManager.OutstandingOperations.Decrement();
                    results.AddRange(e.Tweets);
                };

                search.SearchAsync(searchTerm);
            }
        }

        public ActionResult AsyncCompleted(List<Tweet> results)
        {
            return View("Results", results.OrderByDescending(t => t.Date));
        }

        #region Dragons!

        public ActionResult FakeTwitter(string q)
        {
            Thread.Sleep(500);

            switch (q)
            {
                case "mvcconf": return Content(Resources.Tweets_mvcconf, "application/json");
                case "aspnetmvc": return Content(Resources.Tweets_aspnetmvc, "application/json");
                case "@bradwilson": return Content(Resources.Tweets_bradwilson, "application/json");
                case "@scottgu": return Content(Resources.Tweets_scottgu, "application/json");
            }

            throw new InvalidOperationException("Unknown search term");
        }

        #endregion
    }

    public class TweetsEventArgs : EventArgs
    {
        public IEnumerable<Tweet> Tweets { get; set; }
    }

    public class TwitterSearch
    {
        public delegate void SearchCompletedHandler(object sender, TweetsEventArgs e);

        //const string urlTemplate = "http://search.twitter.com/search.json?q={0}";
        const string urlTemplate = "http://localhost:1337/AsyncTwitterSearch/FakeTwitter?q={0}";

        WebClient webClient = new WebClient();

        public event SearchCompletedHandler SearchCompleted;

        public IEnumerable<Tweet> Search(string term)
        {
            var uriText = String.Format(urlTemplate, term);
            var json = webClient.DownloadString(uriText);
            webClient.Dispose();
            return DecodeJson(json);
        }

        public void SearchAsync(string term)
        {
            var uriText = String.Format(urlTemplate, term);
            webClient.DownloadStringCompleted += webClient_DownloadStringCompleted;
            webClient.DownloadStringAsync(new Uri(uriText));
        }

        void webClient_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            if (SearchCompleted != null)
                SearchCompleted(this, new TweetsEventArgs { Tweets = DecodeJson(e.Result) });

            webClient.Dispose();
        }

        IEnumerable<Tweet> DecodeJson(string json)
        {
            var serializer = new JavaScriptSerializer();
            var jsonObject = (Dictionary<string, object>)serializer.DeserializeObject(json);

            foreach (Dictionary<string, object> result in (IEnumerable)jsonObject["results"])
                yield return new Tweet
                {
                    Html = new HtmlString(result["text"].ToString()),
                    Username = result["from_user"].ToString(),
                    Date = DateTime.Parse(result["created_at"].ToString())
                };
        }
    }
}
