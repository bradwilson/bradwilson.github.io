﻿using System.Web.Mvc;

namespace MvcConf2011.Areas.ContentTypeNegotiation
{
    public class ContentTypeNegotiationAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "ContentTypeNegotiation"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "ContentTypeNegotiation",
                "ContentTypeNegotiation/{action}",
                new { controller = "ContentTypeNegotiation", action = "Index" }
            );
        }
    }
}
