﻿using System.IO;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Script.Serialization;
using System.Xml.Serialization;

namespace MvcConf2011.Areas.ContentTypeNegotiation
{
    public class Contact
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
    }

    public class ContentTypeNegotiationController : Controller
    {
        public object Index()
        {
            Contact model = new Contact { FirstName = "Brad", LastName = "Wilson", Age = 38 };
            return View(model);
        }

        #region === Dragons! ===

        protected override void Initialize(RequestContext requestContext)
        {
            base.Initialize(requestContext);

            //ActionInvoker = new ContentTypeNegotiatingActionInvoker();
        }

        class ContentTypeNegotiatingActionInvoker : ControllerActionInvoker
        {
            protected override ActionResult CreateActionResult(ControllerContext controllerContext, ActionDescriptor actionDescriptor, object actionReturnValue)
            {
                if (actionReturnValue == null)
                    return new EmptyResult();

                ActionResult result = actionReturnValue as ActionResult;
                if (result != null)
                    return result;

                // Asking for JSON?
                if (controllerContext.HttpContext.Request.AcceptTypes.Contains("application/json"))
                {
                    JavaScriptSerializer serializer = new JavaScriptSerializer();
                    string json = serializer.Serialize(actionReturnValue);
                    return new ContentResult { Content = json, ContentType = "application/json" };
                }

                // Asking for XML?
                if (controllerContext.HttpContext.Request.AcceptTypes.Contains("text/xml"))
                {
                    XmlSerializer serializer = new XmlSerializer(actionReturnValue.GetType());
                    using (StringWriter writer = new StringWriter())
                    {
                        serializer.Serialize(writer, actionReturnValue);
                        return new ContentResult { Content = writer.ToString(), ContentType = "text/xml" };
                    }
                }

                // Fall back to HTML as the default, using the object as a model to the default view
                controllerContext.Controller.ViewData.Model = actionReturnValue;
                return new ViewResult
                {
                    TempData = controllerContext.Controller.TempData,
                    ViewData = controllerContext.Controller.ViewData
                };
            }
        }

        #endregion
    }
}
