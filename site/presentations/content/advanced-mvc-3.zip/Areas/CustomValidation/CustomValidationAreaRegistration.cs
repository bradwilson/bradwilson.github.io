﻿using System.Web.Mvc;

namespace MvcConf2011.Areas.CustomValidation
{
    public class CustomValidationAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "CustomValidation"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "CustomValidation",
                "CustomValidation",
                new { controller = "CustomValidation", action = "Index" }
            );
        }
    }
}
