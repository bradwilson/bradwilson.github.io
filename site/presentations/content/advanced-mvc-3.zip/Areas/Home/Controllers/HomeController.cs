﻿using System.Web.Mvc;

namespace MvcConf2011.Areas.Home.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
