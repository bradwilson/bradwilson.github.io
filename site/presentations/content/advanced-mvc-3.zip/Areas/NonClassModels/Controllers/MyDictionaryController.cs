﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace MvcConf2011.Areas.NonClassModels.Controllers
{
    public class MyDictionary : Dictionary<string, string> { }

    public class MyDictionaryController : Controller
    {
        public ActionResult Index()
        {
            return View(new MyDictionary {
                { "foo", "42" },
                { "bar", "baz" }
            });
        }

        [HttpPost]
        public ActionResult Index(MyDictionary model)
        {
            return View(model);
        }
    }
}
