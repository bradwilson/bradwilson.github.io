﻿using System.Linq;
using System.Web.Mvc;
using MvcConf2011.Areas.NonClassModels.Controllers;
using WebActivator;

[assembly: PreApplicationStartMethod(typeof(MvcConf2011.Areas.NonClassModels.NonClassModelsAreaRegistration), "AppStart")]

namespace MvcConf2011.Areas.NonClassModels
{
    public class NonClassModelsAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "NonClassModels"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "NonClassModels",
                "NonClassModels/{action}",
                new { controller = "MyDictionary", action = "Index" }
            );
        }

        public static void AppStart()
        {
            FluentRegistration
                .ForType<MyDictionary>()
                    .ForProperty("foo")
                        .DisplayName("Special Foo")
                    .ForProperty("bar")
                        .DisplayName("Fancy Bar");

            ModelMetadataProviders.Current = new DictionaryModelMetadataProvider(ModelMetadataProviders.Current);

            var oldValidatorProvider = ModelValidatorProviders.Providers.Single(p => p is DataAnnotationsModelValidatorProvider);
            ModelValidatorProviders.Providers.Remove(oldValidatorProvider);
            ModelValidatorProviders.Providers.Add(new DictionaryValidatorProvider(oldValidatorProvider));

            ModelBinderProviders.BinderProviders.Add(new DictionaryModelBinderProvider());
        }
    }
}
