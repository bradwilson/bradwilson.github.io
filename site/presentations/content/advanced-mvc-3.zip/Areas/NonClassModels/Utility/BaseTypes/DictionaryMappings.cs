﻿using System;
using System.Collections.Concurrent;

namespace MvcConf2011.Areas.NonClassModels
{
    public abstract class DictionaryMappings<TTypeInfo> where TTypeInfo : DictionaryTypeInfo
    {
        ConcurrentDictionary<Type, TTypeInfo> mappings = new ConcurrentDictionary<Type, TTypeInfo>();

        public TTypeInfo this[Type type]
        {
            get { return mappings.GetOrAdd(type, CreateTypeInfo); }
        }

        protected ConcurrentDictionary<Type, TTypeInfo> Mappings
        {
            get { return mappings; }
        }

        public bool Contains(Type type)
        {
            return mappings.ContainsKey(type);
        }

        public void RegisterType(Type type)
        {
            mappings.GetOrAdd(type, CreateTypeInfo);
        }

        protected abstract TTypeInfo CreateTypeInfo(Type type);
    }
}