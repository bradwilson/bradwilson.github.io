﻿using System;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryPropertyInfo<TTypeInfo> where TTypeInfo : DictionaryTypeInfo
    {
        public DictionaryPropertyInfo(TTypeInfo typeInfo, string propertyName)
        {
            DictionaryType = typeInfo.DictionaryType;
            ValueType = typeInfo.ValueType;
            PropertyName = propertyName;
        }

        public Type DictionaryType { get; private set; }

        public string PropertyName { get; private set; }

        public Type ValueType { get; private set; }
    }
}