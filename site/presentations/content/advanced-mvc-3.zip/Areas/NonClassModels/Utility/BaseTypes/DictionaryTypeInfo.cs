﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace MvcConf2011.Areas.NonClassModels
{
    public abstract class DictionaryTypeInfo    // Broken in two to prevent cyclical template definitions
    {
        protected DictionaryTypeInfo(Type dictionaryType)
        {
            DictionaryType = dictionaryType;
            ValueType = DictionaryValueTypeCache.Get(dictionaryType);
        }

        public Type DictionaryType { get; private set; }

        public Type ValueType { get; private set; }
    }

    public abstract class DictionaryTypeInfo<TPropertyInfo> : DictionaryTypeInfo
    {
        ConcurrentDictionary<string, TPropertyInfo> properties = new ConcurrentDictionary<string, TPropertyInfo>();

        protected DictionaryTypeInfo(Type dictionaryType) : base(dictionaryType) { }

        public TPropertyInfo this[string propertyName]
        {
            get { return properties.GetOrAdd(propertyName, CreatePropertyInfo); }
        }

        protected abstract TPropertyInfo CreatePropertyInfo(string propertyName);

        public IEnumerable<TPropertyInfo> Properties
        {
            get { return properties.Values; }
        }
    }
}