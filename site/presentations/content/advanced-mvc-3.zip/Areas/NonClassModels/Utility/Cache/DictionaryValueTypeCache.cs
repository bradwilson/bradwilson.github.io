﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace MvcConf2011.Areas.NonClassModels
{
    public static class DictionaryValueTypeCache
    {
        static ConcurrentDictionary<Type, Type> valueTypeMappings = new ConcurrentDictionary<Type, Type>();

        public static Type Get(Type containerType)
        {
            return valueTypeMappings.GetOrAdd(containerType, _ =>
            {
                var genericDictionaryType =
                        containerType
                            .GetInterfaces()
                            .Where(i => i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IDictionary<,>))
                            .FirstOrDefault();

                return genericDictionaryType != null
                    ? genericDictionaryType.GetGenericArguments()[1]
                    : typeof(object);
            });
        }
    }
}