﻿using System;
using System.Collections;

namespace MvcConf2011.Areas.NonClassModels
{
    public class FluentRegistration
    {
        static DictionaryModelMetadataMappings metadataMappings = new DictionaryModelMetadataMappings();
        static DictionaryValidationMappings validationMappings = new DictionaryValidationMappings();

        public static DictionaryModelMetadataMappings MetadataMappings
        {
            get { return metadataMappings; }
        }

        public static DictionaryValidationMappings ValidationMappings
        {
            get { return validationMappings; }
        }

        public static TypeRegistrar ForType<TDictionary>() where TDictionary : IDictionary
        {
            return EnsureTypeIsKnownAndGetTypeRegistrar(typeof(TDictionary));
        }

        public static TypeRegistrar ForType(Type type)
        {
            GuardTypeIsDictionary(type);
            return EnsureTypeIsKnownAndGetTypeRegistrar(type);
        }

        static TypeRegistrar EnsureTypeIsKnownAndGetTypeRegistrar(Type type)
        {
            metadataMappings.RegisterType(type);
            validationMappings.RegisterType(type);
            return new TypeRegistrar(type);
        }

        internal static void GuardTypeIsDictionary(Type type)
        {
            if (!typeof(IDictionary).IsAssignableFrom(type))
                throw new ArgumentException("Mapped types must implement IDictionary", "type");
        }
    }
}