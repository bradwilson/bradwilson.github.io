using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryModelMetadata : ModelMetadata
    {
        Func<IEnumerable<ModelMetadata>> propertiesThunk;

        internal DictionaryModelMetadata(DictionaryModelMetadataProvider provider, Func<object> modelAccessor, DictionaryModelMetadataTypeInfo typeInfo)
            : base(provider, null /* containerType */, modelAccessor, typeInfo.DictionaryType, null /* propertyName */)
        {
            propertiesThunk = () => provider.GetMetadataForProperties(Model, ModelType, typeInfo);
        }

        internal DictionaryModelMetadata(DictionaryModelMetadataProvider provider, Type containerType, Func<object> modelAccessor, DictionaryModelMetadataPropertyInfo propertyInfo)
            : base(provider, containerType, modelAccessor, propertyInfo.ValueType, propertyInfo.PropertyName)
        {
            propertiesThunk = Enumerable.Empty<ModelMetadata>;
        }

        public override IEnumerable<ModelMetadata> Properties
        {
            get { return propertiesThunk(); }
        }

        public Func<DictionaryModelMetadata, string> SimpleDisplayTextCallback { get; set; }

        protected override string GetSimpleDisplayText()
        {
            if (SimpleDisplayTextCallback != null)
                return SimpleDisplayTextCallback(this);

            return base.GetSimpleDisplayText();
        }
    }
}
