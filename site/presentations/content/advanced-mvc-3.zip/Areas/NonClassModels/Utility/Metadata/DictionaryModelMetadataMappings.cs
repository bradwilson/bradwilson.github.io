﻿using System;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryModelMetadataMappings : DictionaryMappings<DictionaryModelMetadataTypeInfo>
    {
        protected override DictionaryModelMetadataTypeInfo CreateTypeInfo(Type type)
        {
            return new DictionaryModelMetadataTypeInfo(type);
        }

        public DictionaryModelMetadata Apply(DictionaryModelMetadata metadata)
        {
            Type type = metadata.ContainerType ?? metadata.ModelType;

            if (Contains(type))
            {
                // Type-level modifiers
                DictionaryModelMetadataTypeInfo typeInfo = this[type];
                foreach (var modifier in typeInfo.Modifiers)
                    modifier(metadata);

                // Property-level modifiers
                if (!String.IsNullOrWhiteSpace(metadata.PropertyName))
                    foreach (var modifier in typeInfo[metadata.PropertyName].Modifiers)
                        modifier(metadata);
            }

            return metadata;
        }
    }
}