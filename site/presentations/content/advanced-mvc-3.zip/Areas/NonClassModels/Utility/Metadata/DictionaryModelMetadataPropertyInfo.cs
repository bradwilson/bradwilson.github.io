using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryModelMetadataPropertyInfo : DictionaryPropertyInfo<DictionaryModelMetadataTypeInfo>
    {
        public DictionaryModelMetadataPropertyInfo(DictionaryModelMetadataTypeInfo typeInfo, string propertyName)
            : base(typeInfo, propertyName)
        {
            Modifiers = new Collection<Action<DictionaryModelMetadata>>();
        }

        public ICollection<Action<DictionaryModelMetadata>> Modifiers { get; private set; }
    }
}
