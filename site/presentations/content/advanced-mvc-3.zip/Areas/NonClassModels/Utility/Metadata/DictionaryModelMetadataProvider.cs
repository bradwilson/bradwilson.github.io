﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.Mvc;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryModelMetadataProvider : ModelMetadataProvider
    {
        ModelMetadataProvider delegatingProvider;
        DictionaryModelMetadataMappings mappings;

        public DictionaryModelMetadataProvider(ModelMetadataProvider delegatingProvider, DictionaryModelMetadataMappings mappings = null)
        {
            this.delegatingProvider = delegatingProvider;
            this.mappings = mappings ?? FluentRegistration.MetadataMappings;
        }

        private static Func<object> GetDictionaryAccessor(IDictionary dictionary, string propertyName)
        {
            return () => dictionary[propertyName];
        }

        public override IEnumerable<ModelMetadata> GetMetadataForProperties(object container, Type containerType)
        {
            if (!mappings.Contains(containerType))
                return delegatingProvider.GetMetadataForProperties(container, containerType);

            return GetMetadataForProperties(container, containerType, mappings[containerType]);
        }

        public IEnumerable<ModelMetadata> GetMetadataForProperties(object container, Type containerType, DictionaryModelMetadataTypeInfo typeInfo)
        {
            IDictionary dictionary = (IDictionary)container;
            foreach (var propertyInfo in typeInfo.Properties)
                yield return GetMetadataForProperty(GetDictionaryAccessor(dictionary, propertyInfo.PropertyName), containerType, propertyInfo);
        }

        public override ModelMetadata GetMetadataForProperty(Func<object> modelAccessor, Type containerType, string propertyName)
        {
            if (!mappings.Contains(containerType))
                return delegatingProvider.GetMetadataForProperty(modelAccessor, containerType, propertyName);

            return GetMetadataForProperty(modelAccessor, containerType, mappings[containerType][propertyName]);
        }

        ModelMetadata GetMetadataForProperty(Func<object> modelAccessor, Type containerType, DictionaryModelMetadataPropertyInfo propertyInfo)
        {
            return mappings.Apply(new DictionaryModelMetadata(this, containerType, modelAccessor, propertyInfo));
        }

        public override ModelMetadata GetMetadataForType(Func<object> modelAccessor, Type modelType)
        {
            if (!mappings.Contains(modelType))
                return delegatingProvider.GetMetadataForType(modelAccessor, modelType);

            return mappings.Apply(new DictionaryModelMetadata(this, modelAccessor, mappings[modelType]));
        }
    }
}