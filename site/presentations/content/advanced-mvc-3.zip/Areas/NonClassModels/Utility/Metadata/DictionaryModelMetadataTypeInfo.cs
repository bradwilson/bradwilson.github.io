using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryModelMetadataTypeInfo : DictionaryTypeInfo<DictionaryModelMetadataPropertyInfo>
    {
        public DictionaryModelMetadataTypeInfo(Type dictionaryType)
            : base(dictionaryType)
        {
            Modifiers = new Collection<Action<DictionaryModelMetadata>>();
        }

        public ICollection<Action<DictionaryModelMetadata>> Modifiers { get; private set; }

        protected override DictionaryModelMetadataPropertyInfo CreatePropertyInfo(string propertyName)
        {
            return new DictionaryModelMetadataPropertyInfo(this, propertyName);
        }
    }
}
