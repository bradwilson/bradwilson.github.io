﻿using System;
using System.Collections.Generic;

namespace MvcConf2011.Areas.NonClassModels
{
    public static class MetadataPropertyRegistrarExtensions
    {
        public static PropertyRegistrar ConvertEmptyStringToNull(this PropertyRegistrar registrar, bool convertEmptyStringToNull)
        {
            registrar.Modifiers().Add(metadata => metadata.ConvertEmptyStringToNull = convertEmptyStringToNull);
            return registrar;
        }

        public static PropertyRegistrar DataTypeName(this PropertyRegistrar registrar, string dataTypeName)
        {
            registrar.Modifiers().Add(metadata => metadata.DataTypeName = dataTypeName);
            return registrar;
        }

        public static PropertyRegistrar Description(this PropertyRegistrar registrar, string description)
        {
            registrar.Modifiers().Add(metadata => metadata.Description = description);
            return registrar;
        }

        public static PropertyRegistrar DisplayFormatString(this PropertyRegistrar registrar, string displayFormatString)
        {
            registrar.Modifiers().Add(metadata => metadata.DisplayFormatString = displayFormatString);
            return registrar;
        }

        public static PropertyRegistrar DisplayName(this PropertyRegistrar registrar, string displayName)
        {
            registrar.Modifiers().Add(metadata => metadata.DisplayName = displayName);
            return registrar;
        }

        public static PropertyRegistrar EditFormatString(this PropertyRegistrar registrar, string editFormatString)
        {
            registrar.Modifiers().Add(metadata => metadata.EditFormatString = editFormatString);
            return registrar;
        }

        public static PropertyRegistrar HideSurroundingHtml(this PropertyRegistrar registrar, bool hideSurroundingHtml)
        {
            registrar.Modifiers().Add(metadata => metadata.HideSurroundingHtml = hideSurroundingHtml);
            return registrar;
        }

        public static PropertyRegistrar IsReadOnly(this PropertyRegistrar registrar, bool isReadOnly)
        {
            registrar.Modifiers().Add(metadata => metadata.IsReadOnly = isReadOnly);
            return registrar;
        }

        public static PropertyRegistrar NullDisplayText(this PropertyRegistrar registrar, string nullDisplayText)
        {
            registrar.Modifiers().Add(metadata => metadata.NullDisplayText = nullDisplayText);
            return registrar;
        }

        public static PropertyRegistrar ShortDisplayName(this PropertyRegistrar registrar, string shortDisplayName)
        {
            registrar.Modifiers().Add(metadata => metadata.ShortDisplayName = shortDisplayName);
            return registrar;
        }

        public static PropertyRegistrar ShowForDisplay(this PropertyRegistrar registrar, bool showForDisplay)
        {
            registrar.Modifiers().Add(metadata => metadata.ShowForDisplay = showForDisplay);
            return registrar;
        }

        public static PropertyRegistrar ShowForEdit(this PropertyRegistrar registrar, bool showForEdit)
        {
            registrar.Modifiers().Add(metadata => metadata.ShowForEdit = showForEdit);
            return registrar;
        }

        public static PropertyRegistrar SimpleDisplayText(this PropertyRegistrar registrar, string simpleDisplayText)
        {
            registrar.Modifiers().Add(metadata => metadata.SimpleDisplayText = simpleDisplayText);
            return registrar;
        }

        public static PropertyRegistrar SkipRequestValidation(this PropertyRegistrar registrar, bool skip = true)
        {
            registrar.Modifiers().Add(metadata => metadata.RequestValidationEnabled = !skip);
            return registrar;
        }

        public static PropertyRegistrar TemplateHint(this PropertyRegistrar registrar, string templateHint)
        {
            registrar.Modifiers().Add(metadata => metadata.TemplateHint = templateHint);
            return registrar;
        }

        public static PropertyRegistrar Watermark(this PropertyRegistrar registrar, string watermark)
        {
            registrar.Modifiers().Add(metadata => metadata.Watermark = watermark);
            return registrar;
        }

        // Helper methods

        static ICollection<Action<DictionaryModelMetadata>> Modifiers(this PropertyRegistrar registrar)
        {
            return FluentRegistration.MetadataMappings[registrar.Type][registrar.PropertyName].Modifiers;
        }
    }
}