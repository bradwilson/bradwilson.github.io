﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace MvcConf2011.Areas.NonClassModels.Utility.Metadata
{
    public static class MetadataTypeRegistrarExtensions
    {
        public static TypeRegistrar SimpleDisplayValue(this TypeRegistrar registrar, string propertyName)
        {
            registrar.Modifiers().Add(metadata => metadata.SimpleDisplayTextCallback = _ => GetSimpleDisplayText(metadata, propertyName));
            return registrar;
        }

        // Helper methods

        static string GetSimpleDisplayText(DictionaryModelMetadata metadata, string propertyName)
        {
            var dictionary = (IDictionary)metadata.Model;
            var value = dictionary[propertyName];
            return value == null ? null : value.ToString();
        }

        static ICollection<Action<DictionaryModelMetadata>> Modifiers(this TypeRegistrar registrar)
        {
            return FluentRegistration.MetadataMappings[registrar.Type].Modifiers;
        }
    }
}