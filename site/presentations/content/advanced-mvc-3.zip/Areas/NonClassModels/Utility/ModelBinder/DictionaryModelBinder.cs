using System;
using System.ComponentModel;
using System.Linq;
using System.Web.Mvc;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryModelBinder : DefaultModelBinder
    {
        DictionaryModelMetadataMappings mappings;

        public DictionaryModelBinder(DictionaryModelMetadataMappings mappings)
        {
            this.mappings = mappings;
        }

        public override object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            // Fallback to empty name if there's nothing with our prefix
            if (!String.IsNullOrEmpty(bindingContext.ModelName) &&
                !bindingContext.ValueProvider.ContainsPrefix(bindingContext.ModelName))
            {
                if (!bindingContext.FallbackToEmptyPrefix)
                    return null;

                bindingContext = new ModelBindingContext
                {
                    ModelMetadata = bindingContext.ModelMetadata,
                    ModelState = bindingContext.ModelState,
                    PropertyFilter = bindingContext.PropertyFilter,
                    ValueProvider = bindingContext.ValueProvider
                };
            }

            object model = bindingContext.Model ?? CreateModel(controllerContext, bindingContext, bindingContext.ModelType);

            bindingContext = new ModelBindingContext
            {
                ModelMetadata = ModelMetadataProviders.Current.GetMetadataForType(() => model, bindingContext.ModelType),
                ModelName = bindingContext.ModelName,
                ModelState = bindingContext.ModelState,
                PropertyFilter = bindingContext.PropertyFilter,
                ValueProvider = bindingContext.ValueProvider
            };

            if (OnModelUpdating(controllerContext, bindingContext))
            {
                foreach (PropertyDescriptor descriptor in GetFilteredModelProperties(controllerContext, bindingContext))
                    BindProperty(controllerContext, bindingContext, descriptor);

                OnModelUpdated(controllerContext, bindingContext);
            }

            return model;
        }

        protected override PropertyDescriptorCollection GetModelProperties(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            Type dictionaryType = bindingContext.ModelType;
            DictionaryModelMetadataTypeInfo typeInfo = mappings[dictionaryType];
            DictionaryModelMetadataPropertyInfo[] properties = typeInfo.Properties.ToArray();
            PropertyDescriptor[] propertyDescriptors = new PropertyDescriptor[properties.Length];

            for (int idx = 0; idx < properties.Length; idx++)
                propertyDescriptors[idx] = new DictionaryPropertyDescriptor(dictionaryType, typeInfo.ValueType, properties[idx].PropertyName);

            return new PropertyDescriptorCollection(propertyDescriptors);
        }

        static bool ShouldPerformRequestValidation(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            return (
                controllerContext == null ||
                controllerContext.Controller == null ||
                bindingContext == null ||
                bindingContext.ModelMetadata == null ||
                (controllerContext.Controller.ValidateRequest && bindingContext.ModelMetadata.RequestValidationEnabled)
            );
        }
    }
}