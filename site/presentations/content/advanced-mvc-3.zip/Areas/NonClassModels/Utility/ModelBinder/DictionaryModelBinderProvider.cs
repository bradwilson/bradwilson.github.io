﻿using System;
using System.Web.Mvc;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryModelBinderProvider : IModelBinderProvider
    {
        DictionaryModelMetadataMappings mappings;

        public DictionaryModelBinderProvider(DictionaryModelMetadataMappings mappings = null)
        {
            this.mappings = mappings ?? FluentRegistration.MetadataMappings;
        }

        public IModelBinder GetBinder(Type modelType)
        {
            if (mappings.Contains(modelType))
                return new DictionaryModelBinder(mappings);

            return null;
        }
    }
}