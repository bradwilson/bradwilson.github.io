using System;
using System.Collections;
using System.ComponentModel;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryPropertyDescriptor : PropertyDescriptor
    {
        Type dictionaryType;
        Type valueType;

        public DictionaryPropertyDescriptor(Type dictionaryType, Type valueType, string propertyName)
            : base(propertyName, new Attribute[0])
        {
            this.dictionaryType = dictionaryType;
            this.valueType = valueType;
        }

        public override Type ComponentType
        {
            get { return dictionaryType; }
        }

        public override bool CanResetValue(object component)
        {
            return false;
        }

        public override object GetValue(object component)
        {
            return ((IDictionary)component)[Name];
        }

        public override bool IsReadOnly
        {
            get { return false; }
        }

        public override Type PropertyType
        {
            get { return valueType; }
        }

        public override void ResetValue(object component)
        {
            throw new NotImplementedException();
        }

        public override void SetValue(object component, object value)
        {
            ((IDictionary)component)[Name] = value;
        }

        public override bool ShouldSerializeValue(object component)
        {
            return false;
        }
    }
}