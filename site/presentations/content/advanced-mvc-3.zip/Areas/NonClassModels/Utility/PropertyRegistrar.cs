using System;
using System.Collections;

namespace MvcConf2011.Areas.NonClassModels
{
    public class PropertyRegistrar
    {
        public PropertyRegistrar(Type type, string propertyName)
        {
            Type = type;
            PropertyName = propertyName;
        }

        public string PropertyName { get; private set; }

        public Type Type { get; private set; }

        public PropertyRegistrar ForProperty(string propertyName)    // Traverse sideways
        {
            return new PropertyRegistrar(Type, propertyName);
        }

        public TypeRegistrar ForType<TDictionary>() where TDictionary : IDictionary    // Traverse up
        {
            return new TypeRegistrar(typeof(TDictionary));
        }

        public TypeRegistrar ForType(Type type)    // Traverse up
        {
            FluentRegistration.GuardTypeIsDictionary(type);
            return new TypeRegistrar(type);
        }
    }
}