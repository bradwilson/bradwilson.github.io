using System;
using System.Collections;

namespace MvcConf2011.Areas.NonClassModels
{
    public class TypeRegistrar
    {
        public TypeRegistrar(Type type)
        {
            Type = type;
        }

        public Type Type { get; private set; }

        public PropertyRegistrar ForProperty(string propertyName)    // Traverse down
        {
            return new PropertyRegistrar(Type, propertyName);
        }

        public TypeRegistrar ForType<TDictionary>() where TDictionary : IDictionary    // Traverse sideways
        {
            return new TypeRegistrar(typeof(TDictionary));
        }

        public TypeRegistrar ForType(Type type)    // Traverse sideways
        {
            FluentRegistration.GuardTypeIsDictionary(type);
            return new TypeRegistrar(type);
        }
    }
}