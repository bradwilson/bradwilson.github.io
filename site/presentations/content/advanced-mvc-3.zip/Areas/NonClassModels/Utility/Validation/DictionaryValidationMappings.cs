﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryValidationMappings : DictionaryMappings<DictionaryValidationTypeInfo>
    {
        protected override DictionaryValidationTypeInfo CreateTypeInfo(Type type)
        {
            return new DictionaryValidationTypeInfo(type);
        }

        public IEnumerable<ModelValidator> GetValidators(Type dictionaryType, ModelMetadata metadata, ControllerContext context)
        {
            DictionaryValidationTypeInfo typeInfo = this[dictionaryType];
            ICollection<Func<ModelMetadata, ControllerContext, ModelValidator>> validatorFactories =
                String.IsNullOrWhiteSpace(metadata.PropertyName)
                    ? typeInfo.Validators                            // Type level validation
                    : typeInfo[metadata.PropertyName].Validators;    // Property level validation

            foreach (var validatorFactory in validatorFactories)
                yield return validatorFactory(metadata, context);
        }
    }
}