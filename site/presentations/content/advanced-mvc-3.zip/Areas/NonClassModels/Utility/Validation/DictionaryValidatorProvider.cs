﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace MvcConf2011.Areas.NonClassModels
{
    public class DictionaryValidatorProvider : ModelValidatorProvider
    {
        ModelValidatorProvider delegatingProvider;
        DictionaryValidationMappings mappings;

        public DictionaryValidatorProvider(ModelValidatorProvider delegatingProvider, DictionaryValidationMappings mappings = null)
        {
            this.delegatingProvider = delegatingProvider;
            this.mappings = mappings ?? FluentRegistration.ValidationMappings;
        }

        public override IEnumerable<ModelValidator> GetValidators(ModelMetadata metadata, ControllerContext context)
        {
            Type dictionaryType = metadata.ContainerType ?? metadata.ModelType;
            if (!mappings.Contains(dictionaryType))
                return delegatingProvider.GetValidators(metadata, context);

            return mappings.GetValidators(dictionaryType, metadata, context);
        }
    }
}