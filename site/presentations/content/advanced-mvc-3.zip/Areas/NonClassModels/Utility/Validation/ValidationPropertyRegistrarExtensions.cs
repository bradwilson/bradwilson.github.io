﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace MvcConf2011.Areas.NonClassModels
{
    public static class ValidationPropertyRegistrarExtensions
    {
        public static PropertyRegistrar Range<T>(this PropertyRegistrar registrar, T minimum, T maximum, string errorMessage = null)
        {
            registrar.Validators().Add((metadata, context) => RangeFactory(metadata, context, typeof(T), minimum.ToString(), maximum.ToString(), errorMessage));
            return registrar;
        }

        public static PropertyRegistrar RegularExpression(this PropertyRegistrar registrar, string pattern, string errorMessage = null)
        {
            registrar.Validators().Add((metadata, context) => RegexFactory(metadata, context, pattern, errorMessage));
            return registrar;
        }

        public static PropertyRegistrar Required(this PropertyRegistrar registrar, string errorMessage = null)
        {
            registrar.Validators().Add((metadata, context) => RequiredFactory(metadata, context, errorMessage));
            return registrar;
        }

        public static PropertyRegistrar StringLength(this PropertyRegistrar registrar, int maximum = Int32.MaxValue, int minimum = 0, string errorMessage = null)
        {
            registrar.Validators().Add((metadata, context) => StringLengthFactory(metadata, context, minimum, maximum, errorMessage));
            return registrar;
        }

        public static PropertyRegistrar Validate(this PropertyRegistrar registrar, Func<ModelMetadata, ControllerContext, ModelValidator> validatorFactory)
        {
            registrar.Validators().Add(validatorFactory);
            return registrar;
        }

        // Helper methods

        private static ModelValidator RangeFactory(ModelMetadata metadata, ControllerContext context, Type type, string minimum, string maximum, string errorMessage)
        {
            var attribute = new RangeAttribute(type, minimum, maximum);

            if (!String.IsNullOrWhiteSpace(errorMessage))
                attribute.ErrorMessage = errorMessage;

            return new RangeAttributeAdapter(metadata, context, attribute);
        }

        private static ModelValidator RegexFactory(ModelMetadata metadata, ControllerContext context, string pattern, string errorMessage)
        {
            var attribute = new RegularExpressionAttribute(pattern);

            if (!String.IsNullOrWhiteSpace(errorMessage))
                attribute.ErrorMessage = errorMessage;

            return new RegularExpressionAttributeAdapter(metadata, context, attribute);
        }

        private static ModelValidator RequiredFactory(ModelMetadata metadata, ControllerContext context, string errorMessage)
        {
            var attribute = new RequiredAttribute();

            if (!String.IsNullOrWhiteSpace(errorMessage))
                attribute.ErrorMessage = errorMessage;

            return new RequiredAttributeAdapter(metadata, context, attribute);
        }

        static ModelValidator StringLengthFactory(ModelMetadata metadata, ControllerContext context, int minimum, int maximum, string errorMessage)
        {
            var attribute = new StringLengthAttribute(maximum) { MinimumLength = minimum };

            if (!String.IsNullOrWhiteSpace(errorMessage))
                attribute.ErrorMessage = errorMessage;

            return new StringLengthAttributeAdapter(metadata, context, attribute);
        }

        static ICollection<Func<ModelMetadata, ControllerContext, ModelValidator>> Validators(this PropertyRegistrar registrar)
        {
            return FluentRegistration.ValidationMappings[registrar.Type][registrar.PropertyName].Validators;
        }
    }
}