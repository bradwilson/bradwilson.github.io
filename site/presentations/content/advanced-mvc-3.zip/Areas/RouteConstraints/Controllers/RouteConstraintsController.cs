﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web.Mvc;
using Microsoft.Web.Mvc;

namespace MvcConf2011.Areas.RouteConstraints.Controllers
{
    [Bind(Exclude = "ID")]
    public class Contact
    {
        public int ID { get; set; }

        [Required, Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required, Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "Twitter Handle")]
        public string TwitterHandle { get; set; }
    }

    public class RouteConstraintsController : Controller
    {
        static List<Contact> contacts = new List<Contact> { 
            new Contact { ID = 1, FirstName = "Brad", LastName = "Wilson", TwitterHandle = "bradwilson" },
            new Contact { ID = 2, FirstName = "Phil", LastName = "Haack", TwitterHandle = "haacked" },
            new Contact { ID = 3, FirstName = "Matthew", LastName = "Osborn", TwitterHandle = "osbornm" },
        };

        public ActionResult List()
        {
            return View(contacts);
        }

        public ActionResult InsertForm()
        {
            return View(TempData["RouteConstraintsInsertModel"]);
        }

        public ActionResult Insert(Contact contact)
        {
            if (!ModelState.IsValid)
            {
                TempData["RouteConstraintsInsertModel"] = contact;
                return RedirectToAction("InsertForm");
            }

            Contact highestID = contacts.OrderByDescending(c => c.ID).FirstOrDefault();
            contact.ID = highestID == null ? 1 : highestID.ID + 1;
            contacts.Add(contact);

            return RedirectToAction("List");
        }

        public ActionResult UpdateForm(int id)
        {
            Contact model = TempData["RouteConstraintsUpdateModel"] as Contact;
            if (model == null)
                model = contacts.Where(c => c.ID == id).FirstOrDefault();
            if (model == null)
                return RedirectToAction("List");

            return View(model);
        }

        public ActionResult Update(int id, Contact updated)
        {
            if (!ModelState.IsValid)
            {
                TempData["RouteConstraintsUpdateModel"] = updated;
                return RedirectToAction("UpdateForm", new { id });
            }

            Contact toUpdate = contacts.Where(c => c.ID == id).FirstOrDefault();
            if (toUpdate == null)
                return RedirectToAction("List");

            ModelCopier.CopyModel(updated, toUpdate);
            return RedirectToAction("List");
        }

        public ActionResult Delete(int id)
        {
            contacts.RemoveAll(c => c.ID == id);
            return RedirectToAction("List");
        }
    }
}
