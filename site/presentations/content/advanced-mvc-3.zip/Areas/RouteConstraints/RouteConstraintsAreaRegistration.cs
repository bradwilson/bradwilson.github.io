﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MvcConf2011.Areas.RouteConstraints
{
    public class RouteConstraintsAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "RouteConstraints"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "RouteConstraints_List",
                "RouteConstraints",
                new { controller = "RouteConstraints", action = "List" },
                new { httpMethod = new MvcMethodConstraint("GET") }
            );

            context.MapRoute(
                "RouteConstraints_Insert",
                "RouteConstraints",
                new { controller = "RouteConstraints", action = "Insert" },
                new { httpMethod = new MvcMethodConstraint("PUT") }
            );

            context.MapRoute(
                "RouteConstraints_Update",
                "RouteConstraints/{id}",
                new { controller = "RouteConstraints", action = "Update" },
                new { httpMethod = new MvcMethodConstraint("POST") }
            );

            context.MapRoute(
                "RouteConstraints_Delete",
                "RouteConstraints/{id}",
                new { controller = "RouteConstraints", action = "Delete" },
                new { httpMethod = new MvcMethodConstraint("DELETE") }
            );

            context.MapRoute(
                "RouteConstraints_InsertForm",
                "RouteConstraints/new",
                new { controller = "RouteConstraints", action = "InsertForm" },
                new { httpMethod = new MvcMethodConstraint("GET") }
            );

            context.MapRoute(
                "RouteConstraints_UpdateForm",
                "RouteConstraints/{id}",
                new { controller = "RouteConstraints", action = "UpdateForm" },
                new { httpMethod = new MvcMethodConstraint("GET") }
            );
        }

        public class MvcMethodConstraint : IRouteConstraint
        {
            public MvcMethodConstraint(params string[] allowedMethods)
            {
                if (allowedMethods == null)
                    throw new ArgumentNullException("allowedMethods");

                AllowedMethods = allowedMethods.ToList();
            }

            public List<string> AllowedMethods { get; private set; }

            public bool Match(HttpContextBase httpContext, Route route, string parameterName, RouteValueDictionary values, RouteDirection routeDirection)
            {
                switch (routeDirection)
                {
                    case RouteDirection.IncomingRequest:
                        string httpMethodOverride = httpContext.Request.GetHttpMethodOverride();
                        return AllowedMethods.Contains(httpMethodOverride, StringComparer.OrdinalIgnoreCase);

                    case RouteDirection.UrlGeneration:
                        object paramValue;
                        if (values.TryGetValue(parameterName, out paramValue))
                            return AllowedMethods.Contains((string)paramValue, StringComparer.OrdinalIgnoreCase);
                        break;
                }

                return true;
            }

            public override string ToString()
            {
                return AllowedMethods.Aggregate((left, right) => left + ", " + right);
            }
        }
    }
}