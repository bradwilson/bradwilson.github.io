﻿using System.Threading;
using System.Web.Mvc;
using MvcConf2011.Areas.StatefulFilters.Utility;

namespace MvcConf2011.Areas.StatefulFilters.Controllers
{
    public class StatefulFiltersController : Controller
    {
        [RequestTimingFilter]
        public ActionResult Index()
        {
            Thread.Sleep(100);
            return View();
        }
    }
}
