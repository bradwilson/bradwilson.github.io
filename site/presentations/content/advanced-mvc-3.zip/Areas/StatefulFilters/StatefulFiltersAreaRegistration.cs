﻿using System.Web.Mvc;

namespace MvcConf2011.Areas.StatefulFilters
{
    public class StatefulFiltersAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get { return "StatefulFilters"; }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "StatefulFilters",
                "StatefulFilters",
                new { controller = "StatefulFilters", action = "Index" }
            );
        }
    }
}