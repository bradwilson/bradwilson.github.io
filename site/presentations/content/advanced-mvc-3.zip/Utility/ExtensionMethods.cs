﻿using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

public static class ExtensionMethods
{
    public static IHtmlString AreaActionLink(this HtmlHelper html, string linkText, string action, string controller, string area)
    {
        return html.ActionLink(linkText, action, controller, new { area }, null);
    }
}