﻿using System.Web.Mvc;

namespace C4MVC.Areas.AsyncControllerDemo {
    public class AsyncControllerDemoAreaRegistration : AreaRegistration {
        public override string AreaName {
            get {
                return "AsyncControllerDemo";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) {
            context.MapRoute(
                "AsyncControllerDemo_default",
                "AsyncControllerDemo/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
