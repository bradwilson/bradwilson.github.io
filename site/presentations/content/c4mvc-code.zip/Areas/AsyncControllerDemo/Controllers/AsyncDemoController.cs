﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.ServiceModel.Syndication;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using C4MVC.Areas.AsyncControllerDemo.Models;

namespace C4MVC.Areas.AsyncControllerDemo.Controllers {
    public class AsyncDemoController : AsyncController {

        public ActionResult Index() {
            return View();
        }

        public void SearchAsync(string q) {
            string[] searchTerms = SplitString(q);
            List<string> allResponses = new List<string>();

            AsyncManager.Parameters["allResponses"] = allResponses;
            AsyncManager.Parameters["searchTerms"] = searchTerms;

            foreach (string term in searchTerms) {
                AsyncManager.OutstandingOperations.Increment();

                WebClient webClient = new WebClient();

                webClient.DownloadStringCompleted += (sender, e) =>
                    {
                        allResponses.Add(e.Result);
                        AsyncManager.OutstandingOperations.Decrement();
                    };

                string url = String.Format("http://search.twitter.com/search.rss?lang=en&q={0}", HttpUtility.UrlEncode(term));
                webClient.DownloadStringAsync(new Uri(url));
            }
        }

        public ActionResult SearchCompleted(List<string> allResponses, string[] searchTerms) {
            var tweets = GetResultsFromText(allResponses, searchTerms).ToArray();
            return View("Search", tweets);
        }

        // turns RSS feed strings into TwitterResults
        private static IEnumerable<TwitterResult> GetResultsFromText(IEnumerable<string> responseTexts, string[] searchTerms) {
            var feeds = from responseText in responseTexts
                        select SyndicationFeed.Load(XmlReader.Create(new StringReader(responseText)));

            return from item in feeds.SelectMany(feed => feed.Items)
                   orderby item.PublishDate descending
                   select new TwitterResult() {
                       Author = item.Authors[0].Email,
                       PostedDate = item.PublishDate,
                       Permalink = item.Links[0].Uri.ToString(),
                       Entry = item.Title.Text,
                       SearchTerms = searchTerms
                   };
        }

        private static string[] SplitString(string q) {
            return (from term in q.Split(',')
                    where !String.IsNullOrWhiteSpace(term)
                    select term.Trim()).ToArray();
        }
    }
}
