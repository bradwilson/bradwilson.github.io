﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace C4MVC.Areas.AsyncControllerDemo.Models {

    public class TwitterResult {

        public string Author { get; set; }

        public DateTimeOffset PostedDate { get; set; }

        public string Permalink { get; set; }

        public string Entry { get; set; }

        public string[] SearchTerms { get; set; }

        #region Colorizing code
        public IHtmlString GetPrettyHtml() {
            IEnumerable<SegmentBase> segments = new LiteralSegment[] { new LiteralSegment() { Value = Entry } };
            for (int i = 0; i < SearchTerms.Length; i++) {
                segments = SplitSegments(segments, SearchTerms[i], i);
            }

            string spanTag = @"<span class=""bold match-{0}"">{1}</span>";
            StringBuilder builder = new StringBuilder();
            foreach (SegmentBase segment in segments) {
                MatchSegment match = segment as MatchSegment;
                if (match != null) {
                    builder.AppendFormat(CultureInfo.InvariantCulture, spanTag, match.SearchTermIndex % 4, match.EncodedValue);
                }
                else {
                    builder.Append(segment.EncodedValue);
                }
            }

            return (IHtmlString)MvcHtmlString.Create(builder.ToString());
        }

        private static IEnumerable<SegmentBase> SplitSegments(IEnumerable<SegmentBase> originalSegments, string searchTerm, int searchTermIndex) {
            foreach (SegmentBase segment in originalSegments) {
                LiteralSegment literal = segment as LiteralSegment;
                if (literal != null) {
                    int originalPos = 0;
                    while (true) {
                        int lastMatchStart = literal.Value.IndexOf(searchTerm, originalPos, StringComparison.OrdinalIgnoreCase);
                        if (lastMatchStart < 0) {
                            // not found
                            yield return new LiteralSegment() { Value = literal.Value.Substring(originalPos) };
                            break;
                        }
                        else {
                            yield return new LiteralSegment() { Value = literal.Value.Substring(originalPos, lastMatchStart - originalPos) };
                            yield return new MatchSegment() { Value = literal.Value.Substring(lastMatchStart, searchTerm.Length), SearchTermIndex = searchTermIndex };
                            originalPos = lastMatchStart + searchTerm.Length;
                        }
                    }
                }
                else {
                    yield return segment;
                }
            }
        }

        private abstract class SegmentBase {
            public string Value;

            public string EncodedValue {
                get {
                    return HttpUtility.HtmlEncode(Value);
                }
            }
        }

        private class LiteralSegment : SegmentBase {
        }

        private class MatchSegment : SegmentBase {
            public int SearchTermIndex;
        }
        #endregion

    }
}