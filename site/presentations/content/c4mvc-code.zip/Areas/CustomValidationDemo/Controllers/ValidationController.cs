﻿using System.Web.Mvc;
using C4MVC.Areas.CustomValidationDemo.Models;

namespace C4MVC.Areas.CustomValidationDemo.Controllers {
    public class ValidationController : Controller {
        public ActionResult Index() {
            return View();
        }

        [HttpPost]
        public ActionResult Index(ProductViewModel model) {
            return View(model);
        }
    }
}
