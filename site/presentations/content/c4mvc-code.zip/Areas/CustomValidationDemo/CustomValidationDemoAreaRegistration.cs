﻿using System.Web.Mvc;
using Microsoft.Web.Mvc.AspNet4;
using C4MVC.Areas.CustomValidationDemo.Validators;

namespace C4MVC.Areas.CustomValidationDemo {
    public class CustomValidationDemoAreaRegistration : AreaRegistration {
        public override string AreaName {
            get {
                return "CustomValidationDemo";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) {
            context.MapRoute(
                "CustomValidationDemo_default",
                "CustomValidationDemo/{action}",
                new { controller = "Validation", action = "Index" }
            );

            DataAnnotations4ModelValidatorProvider.RegisterAdapter(
                typeof(PriceAttribute),
                typeof(PriceValidator)
            );
        }
    }
}
