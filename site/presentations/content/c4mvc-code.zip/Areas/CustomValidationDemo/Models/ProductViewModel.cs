﻿using System.ComponentModel.DataAnnotations;
using C4MVC.Areas.CustomValidationDemo.Validators;

namespace C4MVC.Areas.CustomValidationDemo.Models {
    public class ProductViewModel {
        [Required(ErrorMessage = "This field is required")]
        public string Title { get; set; }

        [Price(MinPrice = 3.99, 
            //ErrorMessage = "Price must end in .99 and be larger than 3.99"
            ErrorMessageResourceType = typeof(Resource1),
            ErrorMessageResourceName = "MyErrorMessage"
            )]
        public double Price { get; set; }
    }
}
