﻿Sys.Mvc.ValidatorRegistry.validators.price = function (rule) {
    // initialization code can go here.
    var minValue = rule.ValidationParameters["min"];

    // we return the function that actually does the validation 
    return function (value, context) {
        if (value > minValue) {
            var cents = value - Math.floor(value);
            if (cents >= 0.99 && cents < 0.995) {
                return true; /* success */
            }
        }

        return rule.ErrorMessage;
    };
};