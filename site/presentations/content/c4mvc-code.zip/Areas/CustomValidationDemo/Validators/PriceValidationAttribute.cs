﻿using System;
using System.ComponentModel.DataAnnotations;

namespace C4MVC.Areas.CustomValidationDemo.Validators {
    public class PriceAttribute : ValidationAttribute {
        public double MinPrice { get; set; }

        public override bool IsValid(object value) {
            if (value == null) {
                return true;
            }

            var price = (double)value;
            if (price < MinPrice) {
                return false;
            }

            double cents = price - Math.Floor(price);
            if (cents < 0.99 || cents >= 0.995) {
                return false;
            }

            return true;
        }
    }
}
