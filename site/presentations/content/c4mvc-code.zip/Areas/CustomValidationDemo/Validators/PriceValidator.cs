﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace C4MVC.Areas.CustomValidationDemo.Validators {
    public class PriceValidator : DataAnnotationsModelValidator<PriceAttribute> {
        double _minPrice;
        string _message;

        public PriceValidator(ModelMetadata metadata, ControllerContext context, PriceAttribute attribute)
            : base(metadata, context, attribute) {
            _minPrice = attribute.MinPrice;
            _message = attribute.FormatErrorMessage("price");
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules() {
            var rule = new ModelClientValidationRule {
                ErrorMessage = _message,
                ValidationType = "price"
            };

            rule.ValidationParameters.Add("min", _minPrice);
            yield return rule;
        }
    }
}