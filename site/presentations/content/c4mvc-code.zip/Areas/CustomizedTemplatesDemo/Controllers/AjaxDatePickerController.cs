﻿using System.Web.Mvc;
using C4MVC.Areas.CustomizedTemplatesDemo.Models;

namespace C4MVC.Areas.CustomizedTemplatesDemo.Controllers {
    public class AjaxDatePickerController : Controller {
        public ActionResult Index() {
            return View();
        }

        [HttpPost]
        public ActionResult Index(EventModel myEvent) {
            return View(myEvent);
        }
    }
}
