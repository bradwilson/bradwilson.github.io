﻿using System.Web.Mvc;

namespace C4MVC.Areas.CustomizedTemplatesDemo {
    public class CustomizedTemplatesDemoAreaRegistration : AreaRegistration {
        public override string AreaName {
            get {
                return "CustomizedTemplatesDemo";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) {
            context.MapRoute(
                "CustomizedTemplatesDemo_default",
                "CustomizedTemplatesDemo/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
