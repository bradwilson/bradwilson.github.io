﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using C4MVC.Areas.DeleteMethodDemo.Models;

namespace C4MVC.Areas.DeleteMethodDemo.Controllers {
    public class PeopleController : Controller {
        PersonRepository repository = new PersonRepository();

        [HttpGet]
        public ActionResult Index() {     // List all
            return View(repository.All.OrderBy(p => p.FullName));
        }

        [HttpPut]
        public ActionResult Index(Person person) {    // Insert new
            if (ModelState.IsValid) {
                repository.Add(person);
                TempData["flash"] = person.FullName + " has been created.";
                return RedirectToAction("index", "person", new { id = person.Id });
            }

            TempData["ModelState"] = ModelState;
            return RedirectToAction("form");
        }

        [HttpGet]
        public ActionResult Form() {    // Insert form
            ModelStateDictionary modelState = TempData["ModelState"] as ModelStateDictionary;
            if (modelState != null)
                ModelState.Merge(modelState);

            return View();
        }
    }
}
