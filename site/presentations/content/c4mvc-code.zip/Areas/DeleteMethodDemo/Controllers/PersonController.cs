﻿using System.Web.Mvc;
using C4MVC.Areas.DeleteMethodDemo.Models;

namespace C4MVC.Areas.DeleteMethodDemo.Controllers {
    public class PersonController : Controller {
        PersonRepository repository = new PersonRepository();

        [HttpGet]
        public ActionResult Index(int id) {    // User details
            return View(repository.Get(id));
        }

        [HttpPost]
        public ActionResult Index(Person person) {    // Update user
            if (ModelState.IsValid) {
                repository.Update(person);
                TempData["flash"] = person.FullName + " has been saved.";
                return RedirectToAction("index");
            }

            TempData["ModelState"] = ModelState;
            return RedirectToAction("form", new { id = person.Id });
        }

        [HttpDelete]
        public ActionResult Index(int id, object unused) {    // Delete user
            string fullName = repository.Get(id).FullName;
            repository.Delete(id);
            TempData["flash"] = fullName + " has been deleted.";
            return RedirectToAction("index", "people");
        }

        [HttpGet]
        public ActionResult Form(int id) {    // Edit form
            Person person = repository.Get(id);
            if (person == null) {
                TempData["flash"] = "Person not found.";
                return RedirectToAction("index", "people");
            }

            ModelStateDictionary modelState = TempData["ModelState"] as ModelStateDictionary;
            if (modelState != null)
                ModelState.Merge(modelState);

            return View(person);
        }
    }
}
