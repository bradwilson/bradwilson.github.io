﻿using System.Web.Mvc;

namespace C4MVC.Areas.DeleteMethodDemo {
    public class DeleteMethodDemoAreaRegistration : AreaRegistration {
        public override string AreaName {
            get {
                return "DeleteMethodDemo";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) {
            context.MapRoute(
                "DeleteMethodDemo_People",
                "DeleteMethodDemo/people/{action}",
                new { controller = "people", action = "index" }
            );

            context.MapRoute(
                "DeleteMethodDemo_Person",
                "DeleteMethodDemo/person/{id}/{action}",
                new { controller = "person", action = "index" },
                new { id = @"\d+" }
            );
        }
    }
}
