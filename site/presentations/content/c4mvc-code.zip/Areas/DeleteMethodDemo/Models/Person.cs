﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace C4MVC.Areas.DeleteMethodDemo.Models {
    public class Person {

        [ScaffoldColumn(false)]
        public int Id { get; set; }

        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [ScaffoldColumn(false)]
        public string FullName { get { return FirstName + " " + LastName; } }
    }
}